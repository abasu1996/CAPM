sap.ui.define([
    "flowmate/controller/BaseController",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageBox"
], (BaseController, JSONModel, MessageBox) => {
    "use strict";

    return BaseController.extend("flowmate.controller.Reports", {
        onInit() {
            const oTo = new Date();
            const oFrom = new Date(oTo.getFullYear(), oTo.getMonth(), 1);
            this.getView().setModel(new JSONModel({
                catalogueVisible: true,
                selectedDashboard: "operational",
                selectedDashboardTitle: this.getText("operationalDashboardTitle"),
                dashboards: [
                    { key: "overallSla", title: this.getText("overallSlaDashboardTitle"), description: this.getText("overallSlaDashboardDescription"), icon: "sap-icon://business-objects-experience" },
                    { key: "averageProcessing", title: this.getText("averageProcessingDashboardTitle"), description: this.getText("averageProcessingDashboardDescription"), icon: "sap-icon://history" },
                    { key: "operational", title: this.getText("operationalDashboardTitle"), description: this.getText("operationalDashboardDescription"), icon: "sap-icon://business-objects-experience" },
                    { key: "sla", title: this.getText("slaDashboardTitle"), description: this.getText("slaDashboardDescription"), icon: "sap-icon://quality-issue" },
                    { key: "teams", title: this.getText("teamDashboardTitle"), description: this.getText("teamDashboardDescription"), icon: "sap-icon://collaborate" },
                    { key: "trends", title: this.getText("trendDashboardTitle"), description: this.getText("trendDashboardDescription"), icon: "sap-icon://line-chart" },
                    { key: "users", title: this.getText("userActivityDashboardTitle"), description: this.getText("userActivityDashboardDescription"), icon: "sap-icon://employee" },
                    { key: "audit", title: this.getText("auditDashboardTitle"), description: this.getText("auditDashboardDescription"), icon: "sap-icon://history" }
                ],
                filters: {
                    fromDate: oFrom,
                    toDate: oTo,
                    processTypeCode: "",
                    subProcessTypeCode: "",
                    statusCode: ""
                },
                totalRequests: 0,
                openRequests: 0,
                completedRequests: 0,
                overdueRequests: 0,
                slaCompliancePercent: 100,
                statusBreakdown: [],
                processBreakdown: [],
                monthlyTrend: [],
                teamWorkload: [],
                userActivity: [],
                auditActivity: [],
                overdueTasks: [],
                overallSlaVolume: 0,
                overallSlaValue: 0,
                overallWithinVolume: 0,
                overallWithinValue: 0,
                overallWithinPercent: 0,
                overallExceededVolume: 0,
                overallExceededValue: 0,
                overallExceededPercent: 0,
                mainFlowSlaMetrics: [],
                subFlowSlaMetrics: [],
                completedProcessingVolume: 0,
                overallAverageProcessingDays: 0,
                mainFlowProcessingMetrics: [],
                subFlowProcessingMetrics: [],
                loaded: false
            }), "reports");
            this.getView().setModel(new JSONModel({
                title: "",
                dashboardKey: "",
                metricKey: "",
                total: 0,
                page: 1,
                pageSize: 25,
                rows: [],
                busy: false,
                hasPrevious: false,
                hasNext: false,
                isSla: false,
                isProcessing: false
            }), "drilldown");
            this.getRouter().getRoute("RouteReports").attachPatternMatched(this.onRouteMatched, this);
        },

        onRouteMatched() {
            this.setOneColumnLayout();
            this._showCatalogue();
        },

        onDashboardTilePress(oEvent) {
            this._openDashboard(oEvent.getSource().data("dashboardKey"));
        },

        onDashboardSelectionChange(oEvent) {
            this._openDashboard(oEvent.getParameter("selectedItem").getKey());
        },

        onShowDashboardCatalogue() {
            this._showCatalogue();
        },

        _showCatalogue() {
            this.getView().getModel("reports").setProperty("/catalogueVisible", true);
        },

        _openDashboard(sKey) {
            const oModel = this.getView().getModel("reports");
            const oDashboard = oModel.getProperty("/dashboards").find((oItem) => oItem.key === sKey);
            if (!oDashboard) {
                return;
            }
            oModel.setProperty("/selectedDashboard", sKey);
            oModel.setProperty("/selectedDashboardTitle", oDashboard.title);
            oModel.setProperty("/catalogueVisible", false);
            this._loadDashboard();
        },

        isDashboardSelected(sSelected, sExpected) {
            return sSelected === sExpected;
        },

        onApplyFilters() {
            this._loadDashboard();
        },

        onResetFilters() {
            const oTo = new Date();
            const oFrom = new Date(oTo.getFullYear(), oTo.getMonth(), 1);
            this.getView().getModel("reports").setProperty("/filters", {
                fromDate: oFrom,
                toDate: oTo,
                processTypeCode: "",
                subProcessTypeCode: "",
                statusCode: ""
            });
            this._loadDashboard();
        },
        async onExportPdf() {
            const oModel = this.getView().getModel("reports");
            const oFilters = oModel.getProperty("/filters");
            if (!oFilters.fromDate || !oFilters.toDate || oFilters.fromDate > oFilters.toDate) {
                MessageBox.warning(this.getText("reportsInvalidDateRange"));
                return;
            }

            try {
                // Always refresh first so the exported dashboard reflects the current filter controls.
                if (!await this._loadDashboard()) {
                    return;
                }
                await this._waitForDashboardRendering();
                const oResult = await this.callAction("exportReportDashboardPdf", {
                    dashboardKey: oModel.getProperty("/selectedDashboard"),
                    filter: {
                        fromDate: this._formatDate(oFilters.fromDate),
                        toDate: this._formatDate(oFilters.toDate),
                        processTypeCode: oFilters.processTypeCode || null,
                        subProcessTypeCode: oFilters.subProcessTypeCode || null,
                        statusCode: oFilters.statusCode || null
                    },
                    charts: this._collectVisibleChartSnapshots()
                });
                this._downloadPdf(oResult.value || oResult);
            } catch (oError) {
                MessageBox.error(this.getErrorMessage(oError, this.getText("dashboardPdfExportFailed")));
            }
        },

        _collectVisibleChartSnapshots() {
            const mChartMetadata = {
                statusBreakdownChart: ["statusBreakdown", this.getText("requestsByStatusTitle")],
                operationalProcessChart: ["processBreakdown", this.getText("requestsByProcessTitle")],
                teamWorkloadChart: ["teamWorkload", this.getText("teamWorkloadTitle")],
                monthlyTrendChart: ["monthlyTrend", this.getText("requestTrendTitle")],
                trendProcessChart: ["processBreakdown", this.getText("requestsByProcessTitle")],
                userActivityChart: ["userActivity", this.getText("activityByUserTitle")],
                auditActivityChart: ["auditActivity", this.getText("activityByActionTitle")],
                overallSlaVolumeChart: ["overallSlaVolume", this.getText("overallSlaVolumeChartTitle")],
                overallSlaValueChart: ["overallSlaValue", this.getText("overallSlaValueChartTitle")],
                averageProcessingChart: ["averageProcessing", this.getText("averageProcessingChartTitle")]
            };
            return Object.entries(mChartMetadata).flatMap(([sControlId, [sChartKey, sTitle]]) => {
                const oChart = this.byId(sControlId);
                if (!oChart || !oChart.getVisible() || !oChart.getDomRef()) {
                    return [];
                }
                const oSize = oChart.getDomRef().getBoundingClientRect();
                return [{
                    chartKey: sChartKey,
                    title: sTitle,
                    svg: oChart.exportToSVGString({
                        width: Math.max(800, Math.round(oSize.width)),
                        height: Math.max(400, Math.round(oSize.height))
                    })
                }];
            });
        },

        _downloadPdf(oExport) {
            const sBinary = String(oExport.content || "").replace(/^data:application\/pdf;base64,/, "");
            const sDecoded = window.atob(sBinary);
            const aBytes = new Uint8Array(sDecoded.length);
            for (let iIndex = 0; iIndex < sDecoded.length; iIndex += 1) {
                aBytes[iIndex] = sDecoded.charCodeAt(iIndex);
            }
            const sUrl = URL.createObjectURL(new Blob([aBytes], { type: oExport.mimeType || "application/pdf" }));
            const oLink = document.createElement("a");
            oLink.href = sUrl;
            oLink.download = oExport.fileName || "flowmate-dashboard.pdf";
            oLink.click();
            URL.revokeObjectURL(sUrl);
        },

        _waitForDashboardRendering() {
            return new Promise((resolve) => {
                window.requestAnimationFrame(() => window.requestAnimationFrame(() => window.setTimeout(resolve, 300)));
            });
        },

        onOverdueTaskPress(oEvent) {
            const sTaskId = oEvent.getSource().getBindingContext("reports")?.getProperty("ID");
            if (sTaskId) {
                this.navTo("RouteApprovalDetail", { taskId: sTaskId });
            }
        },

        async onReportKpiPress(oEvent) {
            const oSource = oEvent.getSource();
            const oReportsModel = this.getView().getModel("reports");
            const oDrilldownModel = this.getView().getModel("drilldown");
            const sDashboardKey = oReportsModel.getProperty("/selectedDashboard");
            oDrilldownModel.setData({
                ...oDrilldownModel.getData(),
                title: `${oSource.getHeader()} - ${this.getText("requestDetailsLabel")}`,
                dashboardKey: sDashboardKey,
                metricKey: oSource.data("metricKey"),
                page: 1,
                rows: [],
                total: 0,
                isSla: sDashboardKey === "overallSla",
                isProcessing: sDashboardKey === "averageProcessing"
            });
            await this._loadReportDrilldown(true);
        },

        async onDrilldownPrevious() {
            const oModel = this.getView().getModel("drilldown");
            oModel.setProperty("/page", Math.max(1, oModel.getProperty("/page") - 1));
            await this._loadReportDrilldown(false);
        },

        async onDrilldownNext() {
            const oModel = this.getView().getModel("drilldown");
            oModel.setProperty("/page", oModel.getProperty("/page") + 1);
            await this._loadReportDrilldown(false);
        },

        onDrilldownRequestPress(oEvent) {
            const sRequestId = oEvent.getSource().getBindingContext("drilldown")?.getProperty("ID");
            if (!sRequestId) {
                return;
            }
            this.onCloseReportDrilldown();
            this.navTo("RouteRequestDetail", { requestId: sRequestId });
        },

        onCloseReportDrilldown() {
            this.byId("reportDrilldownDialog")?.close();
        },

        async _loadReportDrilldown(bOpenDialog) {
            const oReportsModel = this.getView().getModel("reports");
            const oDrilldownModel = this.getView().getModel("drilldown");
            const oFilters = oReportsModel.getProperty("/filters");
            oDrilldownModel.setProperty("/busy", true);
            try {
                const oResult = await this.callAction("getReportDrilldown", {
                    dashboardKey: oDrilldownModel.getProperty("/dashboardKey"),
                    metricKey: oDrilldownModel.getProperty("/metricKey"),
                    page: oDrilldownModel.getProperty("/page"),
                    pageSize: oDrilldownModel.getProperty("/pageSize"),
                    filter: {
                        fromDate: this._formatDate(oFilters.fromDate),
                        toDate: this._formatDate(oFilters.toDate),
                        processTypeCode: oFilters.processTypeCode || null,
                        subProcessTypeCode: oFilters.subProcessTypeCode || null,
                        statusCode: oFilters.statusCode || null
                    }
                });
                const oData = oResult.value || oResult;
                oDrilldownModel.setProperty("/rows", oData.rows || []);
                oDrilldownModel.setProperty("/total", Number(oData.total || 0));
                oDrilldownModel.setProperty("/page", Number(oData.page || 1));
                oDrilldownModel.setProperty("/pageSize", Number(oData.pageSize || 25));
                oDrilldownModel.setProperty("/hasPrevious", Number(oData.page || 1) > 1);
                oDrilldownModel.setProperty("/hasNext", Number(oData.page || 1) * Number(oData.pageSize || 25) < Number(oData.total || 0));
                if (bOpenDialog) {
                    this._pReportDrilldown ||= this.loadFragment({ name: "flowmate.fragment.ReportDrilldown" });
                    const oDialog = await this._pReportDrilldown;
                    oDialog.open();
                }
            } catch (oError) {
                MessageBox.error(this.getErrorMessage(oError, this.getText("reportDrilldownLoadFailed")));
            } finally {
                oDrilldownModel.setProperty("/busy", false);
            }
        },

        async _loadDashboard() {
            const oModel = this.getView().getModel("reports");
            const oFilters = oModel.getProperty("/filters");
            if (!oFilters.fromDate || !oFilters.toDate || oFilters.fromDate > oFilters.toDate) {
                MessageBox.warning(this.getText("reportsInvalidDateRange"));
                return false;
            }

            this.showBusy();
            try {
                const oResult = await this.callAction("getReportDashboard", {
                    filter: {
                        fromDate: this._formatDate(oFilters.fromDate),
                        toDate: this._formatDate(oFilters.toDate),
                        processTypeCode: oFilters.processTypeCode || null,
                        subProcessTypeCode: oFilters.subProcessTypeCode || null,
                        statusCode: oFilters.statusCode || null
                    }
                });
                oModel.setData({
                    ...oModel.getData(),
                    filters: oFilters,
                    ...(oResult.value || oResult),
                    loaded: true
                });
                return true;
            } catch (oError) {
                MessageBox.error(this.getErrorMessage(oError, this.getText("reportsLoadFailed")));
                return false;
            } finally {
                this.hideBusy();
            }
        },

        _formatDate(oDate) {
            const iOffset = oDate.getTimezoneOffset();
            return new Date(oDate.getTime() - iOffset * 60000).toISOString().slice(0, 10);
        }
    });
});

sap.ui.define([
    "flowmate/controller/BaseController",
    "sap/f/library",
    "sap/m/Button",
    "sap/m/Dialog",
    "sap/m/MessageBox",
    "sap/m/MessageToast",
    "sap/m/Select",
    "sap/m/SelectDialog",
    "sap/m/StandardListItem",
    "sap/m/Text",
    "sap/ui/core/Item",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/ui/model/json/JSONModel"
], (BaseController, fLibrary, Button, Dialog, MessageBox, MessageToast, Select, SelectDialog, StandardListItem, Text, Item, Filter, FilterOperator, JSONModel) => {
    "use strict";

    const MAX_ATTACHMENT_SIZE_MB = 400;
    const MAX_ATTACHMENT_SIZE_BYTES = MAX_ATTACHMENT_SIZE_MB * 1024 * 1024;
    const DEMAND_TASK_MODELS = {
    treasury: "treasuryConfirmation",
    wht: "whtClearance",
    budget: "budgetCheck"
};

    return BaseController.extend("flowmate.controller.MyRequests", {
        onInit() {
            this.getView().setModel(new JSONModel(this._createEmptyTask()), "newTask");
            this.getView().setModel(new JSONModel(this._createEmptyParty()), "newParty");
            this.getView().setModel(new JSONModel({
                active: false,
                items: []
            }), "uploads");
            this.getView().setModel(new JSONModel(this._createEmptyEmailDraft()), "emailDraft");
            this.getView().setModel(new JSONModel({
                requestStatus: "",
                taskStatus: ""
            }), "statusEdit");
            this.getView().setModel(new JSONModel({
                sendBackStepNo: "",
                steps: []
            }), "taskAction");
            this.getView().setModel(new JSONModel({
                requestProcessorUser_ID: "",
                requestProcessorName: "",
                requestTeam_ID: "",
                requestTeamName: "",
                taskProcessorUser_ID: "",
                taskProcessorName: "",
                taskTeam_ID: "",
                taskTeamName: ""
            }), "processorEdit");
            this.getView().setModel(new JSONModel({
                midFullScreen: false,
                endFullScreen: false
            }), "fclState");
            this.getView().setModel(new JSONModel({
                editable: false
            }), "requestEdit");
            this.getView().setModel(new JSONModel({
                currentUserId: ""
            }), "requestAccess");
            this.getView().setModel(new JSONModel({
                visible: false,
                loading: false,
                steps: []
            }), "processFlow");
            this.getView().setModel(new JSONModel({
                loading: false,
                requestId: "",
                referenceNumber: "",
                title: "",
                progress: 0,
                progressText: "",
                currentStepText: "",
                steps: [],
                hasSteps: false
            }), "requestProgress");
            this.getView().setModel(new JSONModel({
                showUnreservedOnly: false,
                requestEntitySet: "ProcessRequests"
            }), "viewState");
            this.getView().setModel(new JSONModel({
                processType_code: "",
                subProcessType_code: "",
                search: ""
            }), "requestQueueFilter");
            this.getView().setModel(new JSONModel({
                selectedKey: "",
                items: []
            }), "requestQueueQueries");
            this.getView().setModel(new JSONModel({
                name: ""
            }), "newRequestQuery");
            this.getView().setModel(new JSONModel(this._createEmptyTreasuryConfirmation()), "treasuryConfirmation");
            this.getView().setModel(new JSONModel(this._createEmptyWhtClearance()), "whtClearance");
            this.getView().setModel(new JSONModel({
                showUnreservedOnly: false,
                showTreasuryConfirmation: false,
                showWhtClearance: false,
                 showBudgetCheck: false
            }), "viewDemandTasks");
            this.getView().setModel(new JSONModel(this._createEmptyDemandAssignee()), "budgetCheck");
            this.getRouter().getRoute("RouteMyRequests").attachPatternMatched(this.onRouteMatched, this);
        },

        async onRouteMatched(oEvent) {
            const oQuery = oEvent.getParameter("arguments")["?query"];
            const sRequestId = oQuery && oQuery.requestId;

            this._iPendingDataRequests = 0;
            this._updateBusyState();
            this._bShowUnreservedOnly = oQuery?.unreserved === "true";
            this._bShowReservedOnly = oQuery?.reserved === "true";
            this._sCurrentReservationUserId = null;
            try {
                const oResponse = await this.callAction("getCurrentUserDetails");
                this._sCurrentReservationUserId = (oResponse.value || oResponse).ID || null;
            } catch (oError) {
                this._sCurrentReservationUserId = null;
            }
            this.getView().getModel("requestAccess").setProperty(
                "/currentUserId",
                this._sCurrentReservationUserId || ""
            );
            this.getView().getModel("viewState").setProperty("/showUnreservedOnly", this._bShowUnreservedOnly);
            this.getView().getModel("viewState").setProperty(
                "/requestEntitySet",
                this._bShowUnreservedOnly ? "TeamUnreservedRequests" : "ProcessRequests"
            );
            if (this._bShowUnreservedOnly) {
                this._loadRequestFilterQueries();
            }
            if (!this._bShowUnreservedOnly) {
                this._clearUnreservedQueueFilterState();
            }
            this.setOneColumnLayout();
            this._rebindRequestsTable();

            if (sRequestId) {
                this._showRequestDetailById(sRequestId);
                return;
            }

            this._setRequestsLayout(fLibrary.LayoutType.OneColumn);
        },

        onCreateRequest() {
            this.navTo("RouteRequestCreate", this._getRequestListRouteParameters());
        },

        onCreateSuccessorRequest() {
            if (!this._sSelectedRequestId) {
                MessageToast.show(this.getText("selectRequestMessage"));
                return;
            }

            this.navTo("RouteRequestCreate", this._getRequestListRouteParameters({
                predecessorId: this._sSelectedRequestId
            }));
        },

        onBeforeRebindRequestsTable(oEvent) {
            const oBindingParams = oEvent.getParameter("bindingParams");
            const oEvents = oBindingParams.events || {};
            const fnDataRequested = oEvents.dataRequested;
            const fnDataReceived = oEvents.dataReceived;
            const sExpand = oBindingParams.parameters.expand || "";

            oBindingParams.events = oEvents;
            oBindingParams.filters = oBindingParams.filters || [];
            oBindingParams.parameters.expand = sExpand
                ? `${sExpand},processType,subProcessType`
                : "processType,subProcessType";
            if (this._bShowUnreservedOnly) {
                oBindingParams.filters.push(new Filter("reservedBy", FilterOperator.EQ, null));
                oBindingParams.filters.push(new Filter("status_code", FilterOperator.NE, "PENDING_APPROVAL"));
                this._addUnreservedQueueFilters(oBindingParams.filters);
            }
            if (this._bShowReservedOnly) {
                oBindingParams.filters.push(new Filter(
                    "reservedByUser_ID",
                    FilterOperator.EQ,
                    this._sCurrentReservationUserId || "00000000-0000-0000-0000-000000000000"
                ));
            }
            this._addRequestSearchFilter(oBindingParams.filters);
            oEvents.dataRequested = (...aArgs) => {
                fnDataRequested?.(...aArgs);
                this.onDataRequested();
            };
            oEvents.dataReceived = (...aArgs) => {
                fnDataReceived?.(...aArgs);
                this.onDataReceived();
            };
        },

        _rebindRequestsTable() {
            const oSmartTable = this.byId("requestsSmartTable");

            if (oSmartTable.isInitialised()) {
                oSmartTable.rebindTable(true);
                return;
            }

            oSmartTable.attachEventOnce("initialise", () => {
                oSmartTable.rebindTable(true);
            });
        },

        onUnreservedQueueFilterSearch() {
            if (this._bShowUnreservedOnly) {
                this._syncUnreservedQueueFilterModelFromControls();
                this._filterUnreservedSubProcessTypes();
                this._rebindRequestsTable();
            }
        },

        onUnreservedProcessTypeChange() {
            this.getView().getModel("requestQueueFilter").setProperty("/subProcessType_code", "");
            this.byId("unreservedSubProcessTypeFilter")?.setSelectedKey("");
            this._filterUnreservedSubProcessTypes();
            this.onUnreservedQueueFilterSearch();
        },

        onClearUnreservedQueueFilters() {
            this._clearUnreservedQueueFilterState();
            this._filterUnreservedSubProcessTypes();
            this.onUnreservedQueueFilterSearch();
        },

        onRequestPress(oEvent) {
            const oItem = oEvent.getParameter("listItem") || oEvent.getSource();
            this._openRequest(oItem.getBindingContext());
        },

        async onRequestReferencePress(oEvent) {
            oEvent.cancelBubble?.();

            const oContext = oEvent.getSource().getBindingContext();

            if (oContext) {
                await this._openRequestProgress(oEvent.getSource(), oContext);
            }
        },

        async _openRequestProgress(oSource, oContext) {
            const sRequestId = oContext.getProperty("ID");
            const oProgressModel = this.getView().getModel("requestProgress");
            const oPopover = this.byId("requestProgressPopover");

            if (!sRequestId || !oPopover) {
                return;
            }

            oProgressModel.setData({
                loading: true,
                requestId: sRequestId,
                referenceNumber: oContext.getProperty("referenceNumber") || "",
                title: oContext.getProperty("title") || "",
                progress: 0,
                progressText: this.getText("loadingProgressText"),
                currentStepText: "",
                steps: [],
                hasSteps: false
            });
            oPopover.openBy(oSource);

            try {
                const oRequest = await this._readEntry(`/ProcessRequests(guid'${sRequestId}')`);
                const oTaskResponse = await this.callAction("getGuidedProcessTasks", {
                    requestId: sRequestId
                });
                const aTasks = oTaskResponse.value || oTaskResponse || [];
                const aConfiguredSteps = await this._readList("/ProcessStepConfig", {
                    filters: [new Filter("subProcessType_code", FilterOperator.EQ, oRequest.subProcessType_code)]
                });

                aConfiguredSteps.sort((oLeft, oRight) => Number(oLeft.stepNo || 0) - Number(oRight.stepNo || 0));
                oRequest.tasks = aTasks;
                const aSteps = this._buildProcessFlowSteps(aConfiguredSteps, oRequest)
                    .map((oStep) => this._buildRequestProgressStep(oStep, aTasks, oRequest));
                const iCompleted = aSteps.filter((oStep) => oStep.completed).length;
                const iProgress = aSteps.length ? Math.round((iCompleted / aSteps.length) * 100) : 0;
                const oCurrentStep = aSteps.find((oStep) => oStep.isCurrent)
                    || aSteps.find((oStep) => !oStep.completed)
                    || aSteps[aSteps.length - 1];

                oProgressModel.setData({
                    loading: false,
                    requestId: sRequestId,
                    referenceNumber: oRequest.referenceNumber || oContext.getProperty("referenceNumber") || "",
                    title: oRequest.title || oContext.getProperty("title") || "",
                    progress: iProgress,
                    progressText: this.getText("requestProgressCompletedText", [iCompleted, aSteps.length]),
                    currentStepText: oCurrentStep
                        ? this.getText("requestCurrentStepText", [oCurrentStep.sequenceText, oCurrentStep.stepName])
                        : this.getText("noProcessStepsText"),
                    steps: aSteps,
                    hasSteps: Boolean(aSteps.length)
                });
            } catch (oError) {
                oProgressModel.setProperty("/loading", false);
                oPopover.close();
                MessageBox.error(this.getErrorMessage(oError, this.getText("requestProgressLoadErrorMessage")));
            }
        },

        _buildRequestProgressStep(oStep, aTasks, oRequest) {
            const aStepTasks = aTasks.filter((oTask) => Number(oTask.stepNo || 0) === Number(oStep.stepNo || 0));
            const oActiveTask = aStepTasks.find((oTask) => this._isOpenLikeTask(oTask));
            const bCompleted = oStep.state === "Success";
            const bBreached = !bCompleted && (oStep.isCurrent || Boolean(oActiveTask))
                && this.isSlaBreachedAt(oRequest.slaDueAt, oRequest.dueDate, oRequest.status_code);
            const sOwner = oActiveTask?.processorTeamName
                || oActiveTask?.processor
                || oActiveTask?.assignedTo
                || "";

            return {
                ...oStep,
                completed: bCompleted,
                state: bBreached ? "Error" : oStep.state,
                icon: bBreached ? "sap-icon://lateness" : oStep.icon,
                statusText: bBreached ? this.getText("slaBreachedLabel") : oStep.statusText,
                owner: sOwner,
                ownerVisible: Boolean(sOwner),
                dueDate: (oStep.isCurrent || Boolean(oActiveTask)) ? (oRequest.slaDueAt || oRequest.dueDate || "") : "",
                dueDateVisible: Boolean((oStep.isCurrent || oActiveTask) && (oRequest.slaDueAt || oRequest.dueDate))
            };
        },

        onOpenRequestFromProgress() {
            const sRequestId = this.getView().getModel("requestProgress").getProperty("/requestId");

            this.byId("requestProgressPopover")?.close();
            if (sRequestId) {
                this._showRequestDetailById(sRequestId);
            }
        },

        onCloseRequestProgress() {
            this.byId("requestProgressPopover")?.close();
        },

        onRequestTaskPress(oEvent) {
            const oContext = oEvent.getSource().getBindingContext();
            const sTaskId = oContext && oContext.getProperty("ID");

            if (!sTaskId) {
                MessageToast.show(this.getText("selectTaskMessage"));
                return;
            }

            this._showRequestTaskDetail(sTaskId);
        },

        onRequestTaskReferencePress(oEvent) {
            oEvent.cancelBubble?.();
            this.onRequestTaskPress(oEvent);
        },

        onRelatedRequestPress(oEvent) {
            oEvent.cancelBubble?.();

            const oContext = oEvent.getSource().getBindingContext();
            const sRequestId = oContext?.getProperty("request/ID")
                || oContext?.getProperty("request_ID")
                || oContext?.getProperty("predecessor/ID")
                || oContext?.getProperty("ID")
                || this._sSelectedRequestId;

            if (!sRequestId) {
                MessageToast.show(this.getText("selectRequestMessage"));
                return;
            }

            this._showRequestDetailById(sRequestId);
        },

        onRequestPartyPress(oEvent) {
            const oContext = oEvent.getSource().getBindingContext();
            const sPartyId = oContext && oContext.getProperty("ID");

            if (!sPartyId) {
                MessageToast.show(this.getText("selectPartyMessage"));
                return;
            }

            this._showInvolvedPartyDetail(sPartyId);
        },

        onOpenSelectedRequest() {
            const oSelectedItem = this.byId("requestsTable").getSelectedItem();
            const oContext = oSelectedItem && oSelectedItem.getBindingContext();

            if (!oContext) {
                MessageToast.show(this.getText("selectRequestMessage"));
                return;
            }

            this._showRequestDetail(oContext);
        },

        async onReserveRequest(oEvent) {
            oEvent.cancelBubble?.();

            const oContext = oEvent.getSource().getBindingContext() || this.byId("requestObjectPage").getBindingContext();
            const sRequestId = oContext?.getProperty("ID") || this._sSelectedRequestId;

            if (!sRequestId) {
                MessageToast.show(this.getText("selectRequestMessage"));
                return;
            }

            this.showBusy();

            try {
                await this.callAction("reserveRequest", {
                    requestId: sRequestId
                });
                MessageToast.show(this.getText("requestReservedMessage"));
                this._refreshRequestHeader();
                this.byId("requestsTable").getBinding("items")?.refresh();
            } catch (oError) {
                MessageBox.error(this.getErrorMessage(oError, this.getText("requestReserveErrorMessage")));
            } finally {
                this.hideBusy();
            }
        },

        onChangeRequestTeamAndRelease() {
            if (!this._sSelectedRequestId) {
                MessageToast.show(this.getText("selectRequestMessage"));
                return;
            }

            if (!this._oChangeRequestTeamDialog) {
                this._oChangeRequestTeamDialog = new SelectDialog({
                    title: this.getText("changeRequestTeamDialogTitle"),
                    noDataText: this.getText("noProcessorTeamsMessage"),
                    liveChange: (oEvent) => this._filterChangeRequestTeams(oEvent.getSource(), oEvent.getParameter("value")),
                    search: (oEvent) => this._filterChangeRequestTeams(oEvent.getSource(), oEvent.getParameter("value")),
                    confirm: (oEvent) => this._confirmRequestTeamChange(oEvent.getParameter("selectedItem"))
                });
                this._oChangeRequestTeamDialog.bindAggregation("items", {
                    path: "/Teams",
                    filters: [new Filter("isActive", FilterOperator.EQ, true)],
                    template: new StandardListItem({
                        title: "{name}",
                        description: "{teamCode}",
                        type: "Active"
                    })
                });
                this.getView().addDependent(this._oChangeRequestTeamDialog);
            }

            this._oChangeRequestTeamDialog.getBinding("items")?.filter([
                new Filter("isActive", FilterOperator.EQ, true)
            ]);
            this._oChangeRequestTeamDialog.open();
        },

        _filterChangeRequestTeams(oDialog, sValue) {
            const aFilters = [new Filter("isActive", FilterOperator.EQ, true)];
            const sQuery = (sValue || "").trim();
            if (sQuery) {
                aFilters.push(new Filter({
                    filters: [
                        new Filter("name", FilterOperator.Contains, sQuery),
                        new Filter("teamCode", FilterOperator.Contains, sQuery)
                    ],
                    and: false
                }));
            }
            oDialog.getBinding("items")?.filter(aFilters);
        },

        _confirmRequestTeamChange(oTeamItem) {
            const oTeamContext = oTeamItem?.getBindingContext();
            const sTeamId = oTeamContext?.getProperty("ID");
            const sTeamName = oTeamContext?.getProperty("name") || oTeamContext?.getProperty("teamCode");
            const oRequest = this.byId("requestObjectPage")?.getBindingContext()?.getObject();

            if (!sTeamId || !oRequest) {
                return;
            }
            if (sTeamId === oRequest.processorTeam_ID) {
                MessageToast.show(this.getText("selectDifferentTeamMessage"));
                return;
            }

            MessageBox.confirm(this.getText("confirmRequestTeamReleaseMessage", [sTeamName]), {
                actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
                emphasizedAction: MessageBox.Action.OK,
                onClose: (sAction) => {
                    if (sAction === MessageBox.Action.OK) {
                        this._releaseRequestToTeam(sTeamId, sTeamName);
                    }
                }
            });
        },

        async _releaseRequestToTeam(sTeamId, sTeamName) {
            this.showBusy();
            try {
                await this.callAction("changeRequestTeamAndRelease", {
                    requestId: this._sSelectedRequestId,
                    teamId: sTeamId
                });
                MessageToast.show(this.getText("requestReleasedToTeamMessage", [sTeamName]));
                this._refreshRequestHeader();
                this._refreshTaskSection();
                this._refreshHistorySection();
                this.byId("requestsTable").getBinding("items")?.refresh(true);
            } catch (oError) {
                MessageBox.error(this.getErrorMessage(oError, this.getText("requestTeamReleaseErrorMessage")));
            } finally {
                this.hideBusy();
            }
        },

        onOpenAssignRequestUserDialog() {
            if (!this._sSelectedRequestId) {
                MessageToast.show(this.getText("selectRequestMessage"));
                return;
            }

            this.byId("assignRequestUserDialog").open();
        },

        onAssignRequestUserSearch(oEvent) {
            this._filterUsers(oEvent.getSource(), oEvent.getParameter("value") || "");
        },

        async onAssignRequestUserConfirm(oEvent) {
            const oContext = oEvent.getParameter("selectedItem")?.getBindingContext();
            const sUserId = oContext?.getProperty("ID");

            if (!this._sSelectedRequestId || !sUserId) {
                return;
            }

            this.showBusy();
            try {
                await this.callAction("assignRequestToUser", {
                    requestId: this._sSelectedRequestId,
                    userId: sUserId
                });
                MessageToast.show(this.getText("requestAssignedToUserMessage", [oContext.getProperty("displayName")]));
                this._refreshRequestHeader();
                this._refreshTaskSection();
                this._refreshHistorySection();
                this.byId("requestsTable").getBinding("items")?.refresh();
            } catch (oError) {
                MessageBox.error(this.getErrorMessage(oError, this.getText("requestAssignToUserErrorMessage")));
            } finally {
                this.hideBusy();
            }
        },

        onAssignRequestUserClose(oEvent) {
            oEvent.getSource().getBinding("items")?.filter([]);
        },

        onSearch(oEvent) {
            const sQuery = oEvent.getParameter("query") || oEvent.getParameter("newValue") || "";

            this.getView().getModel("requestQueueFilter").setProperty("/search", sQuery);
            this._rebindRequestsTable();
        },

        onSavedRequestQueryChange(oEvent) {
            const sQueryId = oEvent.getSource().getSelectedKey();
            const aQueries = this.getView().getModel("requestQueueQueries").getProperty("/items") || [];
            const oQuery = aQueries.find((oItem) => oItem.ID === sQueryId);

            if (!oQuery) {
                return;
            }

            this._applyRequestFilterQuery(oQuery);
        },

        onOpenSaveQueryDialog() {
            const sSelectedQueryId = this.getView().getModel("requestQueueQueries").getProperty("/selectedKey");
            const aQueries = this.getView().getModel("requestQueueQueries").getProperty("/items") || [];
            const oSelectedQuery = aQueries.find((oItem) => oItem.ID === sSelectedQueryId);

            this._syncUnreservedQueueFilterModelFromControls();
            this.getView().getModel("newRequestQuery").setProperty("/name", oSelectedQuery?.name || "");
            this.byId("saveRequestQueryDialog").open();
        },

        onCloseSaveQueryDialog() {
            this.byId("saveRequestQueryDialog").close();
        },

        async onSaveRequestQuery() {
            const oNameModel = this.getView().getModel("newRequestQuery");
            const sName = (oNameModel.getProperty("/name") || "").trim();

            if (!sName) {
                MessageBox.error(this.getText("queryNameRequiredMessage"));
                return;
            }

            this._syncUnreservedQueueFilterModelFromControls();

            const oFilterData = this.getView().getModel("requestQueueFilter").getData();
            const oPayload = {
                name: sName,
                processType_code: oFilterData.processType_code || null,
                subProcessType_code: oFilterData.subProcessType_code || null,
                search: oFilterData.search || null
            };
            const oQueryModel = this.getView().getModel("requestQueueQueries");
            const sSelectedQueryId = oQueryModel.getProperty("/selectedKey");

            this.showBusy();

            try {
                if (sSelectedQueryId) {
                    await this.updateEntry(this._requestFilterQueryPath(sSelectedQueryId), oPayload);
                } else {
                    const oCreated = await this.createEntry("/RequestFilterQueries", oPayload);
                    oQueryModel.setProperty("/selectedKey", oCreated.ID || "");
                }

                await this._loadRequestFilterQueries(oQueryModel.getProperty("/selectedKey"));
                this.byId("saveRequestQueryDialog").close();
                MessageToast.show(this.getText("querySavedMessage"));
            } catch (oError) {
                MessageBox.error(this.getErrorMessage(oError, this.getText("querySaveErrorMessage")));
            } finally {
                this.hideBusy();
            }
        },

        async onDeleteSavedRequestQuery() {
            const oQueryModel = this.getView().getModel("requestQueueQueries");
            const sQueryId = oQueryModel.getProperty("/selectedKey");

            if (!sQueryId) {
                return;
            }

            const bConfirmed = await new Promise((resolve) => {
                MessageBox.confirm(this.getText("deleteSavedQueryConfirmMessage"), {
                    onClose: (sAction) => resolve(sAction === MessageBox.Action.OK)
                });
            });

            if (!bConfirmed) {
                return;
            }

            this.showBusy();

            try {
                await this.removeEntry(this._requestFilterQueryPath(sQueryId));
                oQueryModel.setProperty("/selectedKey", "");
                await this._loadRequestFilterQueries();
                MessageToast.show(this.getText("queryDeletedMessage"));
            } catch (oError) {
                MessageBox.error(this.getErrorMessage(oError, this.getText("queryDeleteErrorMessage")));
            } finally {
                this.hideBusy();
            }
        },

        onCloseRequestDetail() {
            this._resetRequestSelection();
            this.navTo("RouteMyRequests", this._getRequestListRouteParameters(), true);
        },

        onCloseRequestTaskDetail() {
            this._sSelectedTaskId = null;
            this._sTaskDetailLoadToken = null;
            this._setRequestsLayout(fLibrary.LayoutType.TwoColumnsMidExpanded);
        },

        onCloseInvolvedPartyDetail() {
            this._sSelectedPartyId = null;
            this._setRequestsLayout(fLibrary.LayoutType.TwoColumnsMidExpanded);
        },

        onRefreshRequestDetail() {
            this._refreshAllRequestSections();
            this.byId("requestsTable").getBinding("items")?.refresh();
        },

        onRefreshRequestTaskDetail() {
            this.byId("requestTaskObjectPage").getElementBinding()?.refresh();
            this._refreshAfterTaskChange();
        },

        onRefreshInvolvedPartyDetail() {
            this.byId("requestPartyObjectPage").getElementBinding()?.refresh();
            this._refreshPartySection();
        },

        onToggleRequestFullScreen() {
            const sLayout = this.byId("requestsFlexibleColumnLayout").getLayout();

            if (sLayout === fLibrary.LayoutType.MidColumnFullScreen) {
                this._setRequestsLayout(this._sMidRestoreLayout || fLibrary.LayoutType.TwoColumnsMidExpanded);
                return;
            }

            this._sMidRestoreLayout = sLayout;
            this._setRequestsLayout(fLibrary.LayoutType.MidColumnFullScreen);
        },

        onToggleRequestTaskFullScreen() {
            const sLayout = this.byId("requestsFlexibleColumnLayout").getLayout();

            if (sLayout === fLibrary.LayoutType.EndColumnFullScreen) {
                this._setRequestsLayout(this._sEndRestoreLayout || fLibrary.LayoutType.ThreeColumnsEndExpanded);
                return;
            }

            this._sEndRestoreLayout = sLayout;
            this._setRequestsLayout(fLibrary.LayoutType.EndColumnFullScreen);
        },

        async onSaveRequestStatus() {
            const sStatusCode = this.getView().getModel("statusEdit").getProperty("/requestStatus");

            return this._updateRequestStatus(sStatusCode);
        },

        async onRequestStatusAction(oEvent) {
            return this._updateRequestStatus(oEvent.getSource().getKey());
        },

        async _updateRequestStatus(sStatusCode) {

            if (!this._sSelectedRequestId || !sStatusCode) {
                return;
            }

            this.showBusy();

            try {
                await this.callAction("updateRequestStatus", {
                    requestId: this._sSelectedRequestId,
                    statusCode: sStatusCode
                });
                MessageToast.show(this.getText("requestStatusUpdatedMessage"));
                this._refreshRequestHeader();
                this._refreshHistorySection();
                this.byId("requestsTable").getBinding("items").refresh();
            } catch (oError) {
                MessageBox.error(this.getErrorMessage(oError, this.getText("statusUpdateErrorMessage")));
            } finally {
                this.hideBusy();
            }
        },

        async onSaveRequestTaskStatus() {
            const sStatusCode = this.getView().getModel("statusEdit").getProperty("/taskStatus");

            if (!this._sSelectedTaskId || !sStatusCode) {
                return;
            }

            this.showBusy();

            try {
                await this.callAction("updateTaskStatus", {
                    taskId: this._sSelectedTaskId,
                    statusCode: sStatusCode
                });
                MessageToast.show(this.getText("taskStatusUpdatedMessage"));
                this._refreshAfterTaskChange();
                this.byId("requestTaskObjectPage").getElementBinding().refresh();
            } catch (oError) {
                MessageBox.error(this.getErrorMessage(oError, this.getText("statusUpdateErrorMessage")));
            } finally {
                this.hideBusy();
            }
        },

        onRequestProcessorValueHelpRequest() {
            this._sProcessorValueHelpTarget = "request";
            this.byId("myRequestsProcessorValueHelpDialog").open();
        },

        onRequestTaskProcessorValueHelpRequest() {
            this._sProcessorValueHelpTarget = "task";
            this.byId("myRequestsProcessorValueHelpDialog").open();
        },

        onNewTaskProcessorValueHelpRequest() {
            this._sProcessorValueHelpTarget = "newTask";
            this.byId("myRequestsProcessorValueHelpDialog").open();
        },

        onRequestTeamValueHelpRequest() {
            this._sTeamValueHelpTarget = "request";
            this.byId("myRequestsTeamValueHelpDialog").open();
        },

        onRequestTaskTeamValueHelpRequest() {
            this._sTeamValueHelpTarget = "task";
            this.byId("myRequestsTeamValueHelpDialog").open();
        },

        onNewTaskTeamValueHelpRequest() {
            this._sTeamValueHelpTarget = "newTask";
            this.byId("myRequestsTeamValueHelpDialog").open();
        },

        onRequestProcessorSuggestionSelected(oEvent) {
            this._applyProcessorSelection(this._getSuggestionContext(oEvent), "request");
        },

        onRequestTaskProcessorSuggestionSelected(oEvent) {
            this._applyProcessorSelection(this._getSuggestionContext(oEvent), "task");
        },

        onNewTaskProcessorSuggestionSelected(oEvent) {
            this._applyProcessorSelection(this._getSuggestionContext(oEvent), "newTask");
        },

        onRequestTeamSuggestionSelected(oEvent) {
            this._applyTeamSelection(this._getSuggestionContext(oEvent), "request");
        },

        onRequestTaskTeamSuggestionSelected(oEvent) {
            this._applyTeamSelection(this._getSuggestionContext(oEvent), "task");
        },

        onNewTaskTeamSuggestionSelected(oEvent) {
            this._applyTeamSelection(this._getSuggestionContext(oEvent), "newTask");
        },

        onRequestProcessorLiveChange() {
            this.getView().getModel("processorEdit").setProperty("/requestProcessorUser_ID", "");
        },

        onRequestTaskProcessorLiveChange() {
            this.getView().getModel("processorEdit").setProperty("/taskProcessorUser_ID", "");
        },

        onNewTaskProcessorLiveChange() {
            const oModel = this.getView().getModel("newTask");
            oModel.setProperty("/processorUser_ID", "");
            oModel.setProperty("/processor", "");
            oModel.setProperty("/processorEmail", "");
        },

        onRequestTeamLiveChange() {
            this.getView().getModel("processorEdit").setProperty("/requestTeam_ID", "");
        },

        onRequestTaskTeamLiveChange() {
            this.getView().getModel("processorEdit").setProperty("/taskTeam_ID", "");
        },

        onNewTaskTeamLiveChange() {
            this.getView().getModel("newTask").setProperty("/processorTeam_ID", "");
        },

        onTeamValueHelpSearch(oEvent) {
            const sQuery = oEvent.getParameter("value") || "";
            const oBinding = oEvent.getSource().getBinding("items");

            if (!sQuery) {
                oBinding.filter([]);
                return;
            }

            oBinding.filter([
                new Filter({
                    filters: [
                        new Filter("teamCode", FilterOperator.Contains, sQuery),
                        new Filter("name", FilterOperator.Contains, sQuery),
                        new Filter("description", FilterOperator.Contains, sQuery)
                    ],
                    and: false
                })
            ]);
        },

        onTeamValueHelpConfirm(oEvent) {
            const oContext = oEvent.getParameter("selectedItem")?.getBindingContext();

            if (!oContext) {
                return;
            }

            this._applyTeamSelection(oContext, this._sTeamValueHelpTarget);

            this.onTeamValueHelpClose(oEvent);
        },

        onTeamValueHelpClose(oEvent) {
            oEvent.getSource().getBinding("items")?.filter([]);
        },

        onProcessorValueHelpSearch(oEvent) {
            this._filterUsers(oEvent.getSource(), oEvent.getParameter("value") || "");
        },

        onProcessorValueHelpConfirm(oEvent) {
            const oContext = oEvent.getParameter("selectedItem")?.getBindingContext();

            if (!oContext) {
                return;
            }

            this._applyProcessorSelection(oContext, this._sProcessorValueHelpTarget);

            this.onProcessorValueHelpClose(oEvent);
        },

        onProcessorValueHelpClose(oEvent) {
            oEvent.getSource().getBinding("items")?.filter([]);
        },

        async onSaveRequestProcessor() {
            const sProcessorUserId = this.getView().getModel("processorEdit").getProperty("/requestProcessorUser_ID");

            if (!this._sSelectedRequestId || !sProcessorUserId) {
                MessageToast.show(this.getText("selectProcessorMessage"));
                return;
            }

            this.showBusy();

            try {
                await this.callAction("assignRequestProcessor", {
                    requestId: this._sSelectedRequestId,
                    processorUserId: sProcessorUserId
                });
                MessageToast.show(this.getText("requestProcessorUpdatedMessage"));
                this._refreshRequestHeader();
                this._refreshTaskSection();
                this._refreshHistorySection();
            } catch (oError) {
                MessageBox.error(this.getErrorMessage(oError, this.getText("processorUpdateErrorMessage")));
            } finally {
                this.hideBusy();
            }
        },

        async onSaveRequestTeam() {
            const sTeamId = this.getView().getModel("processorEdit").getProperty("/requestTeam_ID");

            if (!this._sSelectedRequestId || !sTeamId) {
                MessageToast.show(this.getText("selectTeamMessage"));
                return;
            }

            this.showBusy();

            try {
                await this.callAction("assignRequestTeam", {
                    requestId: this._sSelectedRequestId,
                    teamId: sTeamId
                });
                MessageToast.show(this.getText("requestTeamUpdatedMessage"));
                this._refreshRequestHeader();
                this._refreshHistorySection();
            } catch (oError) {
                MessageBox.error(this.getErrorMessage(oError, this.getText("teamUpdateErrorMessage")));
            } finally {
                this.hideBusy();
            }
        },

        async onSaveRequestTaskProcessor() {
            const sProcessorUserId = this.getView().getModel("processorEdit").getProperty("/taskProcessorUser_ID");

            if (!this._sSelectedTaskId || !sProcessorUserId) {
                MessageToast.show(this.getText("selectProcessorMessage"));
                return;
            }

            this.showBusy();

            try {
                await this.callAction("assignTaskProcessor", {
                    taskId: this._sSelectedTaskId,
                    processorUserId: sProcessorUserId
                });
                MessageToast.show(this.getText("taskProcessorUpdatedMessage"));
                this._refreshTaskSection();
                this._refreshHistorySection();
                this.byId("requestTaskObjectPage").getElementBinding().refresh();
            } catch (oError) {
                MessageBox.error(this.getErrorMessage(oError, this.getText("processorUpdateErrorMessage")));
            } finally {
                this.hideBusy();
            }
        },

        async onSaveRequestTaskTeam() {
            const sTeamId = this.getView().getModel("processorEdit").getProperty("/taskTeam_ID");

            if (!this._sSelectedTaskId || !sTeamId) {
                MessageToast.show(this.getText("selectTeamMessage"));
                return;
            }

            this.showBusy();

            try {
                await this.callAction("assignTaskTeam", {
                    taskId: this._sSelectedTaskId,
                    teamId: sTeamId
                });
                MessageToast.show(this.getText("taskTeamUpdatedMessage"));
                this._refreshTaskSection();
                this._refreshHistorySection();
                this.byId("requestTaskObjectPage").getElementBinding().refresh();
            } catch (oError) {
                MessageBox.error(this.getErrorMessage(oError, this.getText("teamUpdateErrorMessage")));
            } finally {
                this.hideBusy();
            }
        },

        async onApproveRequestTask() {
            const oContext = this.byId("requestTaskObjectPage").getBindingContext();
            const sTaskName = oContext?.getProperty("taskName");
            const sSubProcessTypeCode = oContext?.getProperty("request/subProcessType_code");
            const sRequestId = oContext?.getProperty("request/ID") || oContext?.getProperty("request_ID");

            if (sTaskName === "GFA Team Confirmation" && sSubProcessTypeCode === "NON_PO_MISC_RECEIPTS") {
                const sDebitGL = (this.byId("requestGfaDebitGLInput").getValue() || "").trim();

                if (!sDebitGL) {
                    MessageBox.warning(this.getText("debitGLRequiredMessage"));
                    return;
                }

                if (!sRequestId) {
                    MessageBox.error(this.getText("selectRequestMessage"));
                    return;
                }

                this.showBusy();

                try {
                    await this.updateEntry(`/ProcessRequests(guid'${sRequestId}')`, {
                        debitGL: sDebitGL
                    });
                } catch (oError) {
                    this.hideBusy();
                    MessageBox.error(this.getErrorMessage(oError, this.getText("debitGLSaveErrorMessage")));
                    return;
                }

                this.hideBusy();
            }
             if (sTaskName === "IV Confirmation and Document Archiving" && sSubProcessTypeCode === "NON_PO_TAX_LIAB_PAY_PAYORDER") {
                const sVoucherNumber = (this.byId("requestIvVoucherNumberInput").getValue() || "").trim();
                const sConfirmationValue = (this.byId("requestIvConfirmationValueInput").getValue() || "").trim();
                const sBankStatus = (this.byId("requestIvBankStatusInput").getValue() || "").trim();

                if (!sVoucherNumber || !sConfirmationValue || !sBankStatus) {
                    MessageBox.warning(this.getText("ivConfirmationFieldsRequiredMessage"));
                    return;
                }

                if (!sRequestId) {
                    MessageBox.error(this.getText("selectRequestMessage"));
                    return;
                }

                this.showBusy();

                try {
                    await this.updateEntry(`/ProcessRequests(guid'${sRequestId}')`, {
                        voucherNumber: sVoucherNumber,
                        ivConfirmationValue: sConfirmationValue,
                        bankStatus: sBankStatus
                    });
                } catch (oError) {
                    this.hideBusy();
                    MessageBox.error(this.getErrorMessage(oError, this.getText("ivConfirmationSaveErrorMessage")));
                    return;
                }

                this.hideBusy();
            }
            await this._completeRequestTask("approveTask", "taskApprovedMessage");
        },

        async onRejectRequestTask() {
            await this._completeRequestTask("rejectTask", "taskRejectedMessage");
        },

        async onSendBackRequestTask() {
            await this._completeRequestTask("sendBack", "taskSentBackMessage");
        },

        async onOpenRequestEmailDialog() {
            if (!this._sSelectedRequestId) {
                MessageToast.show(this.getText("selectRequestMessage"));
                return;
            }

            const oContext = this.byId("requestObjectPage").getBindingContext();
            const oRequest = oContext?.getObject() || {};
            const sReferenceNumber = oRequest.referenceNumber || "";
            const sTitle = oRequest.title || "";

            this.showBusy();

            try {
                const aAttachments = await this._readList("/ProcessAttachments", {
                    filters: [new Filter("request_ID", FilterOperator.EQ, this._sSelectedRequestId)]
                });

                this.getView().getModel("emailDraft").setData({
                    requestId: this._sSelectedRequestId,
                    toRecipients: "",
                    toTokens: [],
                    ccRecipients: "",
                    subject: this.getText("requestEmailDefaultSubject", [sReferenceNumber, sTitle]),
                    body: this.getText("requestEmailDefaultBody", [sReferenceNumber, sTitle, window.location.href]),
                    attachments: aAttachments.map((oAttachment) => ({
                        ID: oAttachment.ID,
                        referenceNumber: oAttachment.referenceNumber,
                        filename: oAttachment.filename,
                        mimeType: oAttachment.mimeType,
                        status: oAttachment.status,
                        include: true
                    }))
                });
                this.byId("requestEmailDialog").open();
            } catch (oError) {
                MessageBox.error(this.getErrorMessage(oError, this.getText("requestEmailAttachmentLoadErrorMessage")));
            } finally {
                this.hideBusy();
            }
        },

        onCloseRequestEmailDialog() {
            this.byId("requestEmailDialog").close();
        },

        onEmailToUserValueHelpRequest() {
            this.byId("requestEmailToUserDialog").open();
        },

        onEmailToSuggestionSelected(oEvent) {
            const oContext = this._getSuggestionContext(oEvent);

            if (!oContext) {
                return;
            }

            this._addEmailToRecipients([{
                email: oContext.getProperty("email") || oContext.getProperty("userPrincipalName"),
                displayName: oContext.getProperty("displayName")
            }]);
            oEvent.getSource().setValue("");
        },

        onEmailToUserValueHelpSearch(oEvent) {
            this._filterUsers(oEvent.getSource(), oEvent.getParameter("value") || "");
        },

        onEmailToUserValueHelpConfirm(oEvent) {
            const aContexts = oEvent.getParameter("selectedContexts")
                || (oEvent.getParameter("selectedItems") || [])
                    .map((oItem) => oItem.getBindingContext())
                    .filter(Boolean);

            if (aContexts.length) {
                this._addEmailToRecipients(aContexts.map((oContext) => ({
                    email: oContext.getProperty("email"),
                    displayName: oContext.getProperty("displayName")
                })));
            }

            this.onEmailToUserValueHelpClose(oEvent);
        },

        onEmailToUserValueHelpClose(oEvent) {
            oEvent.getSource().getBinding("items")?.filter([]);
        },

        onEmailToTokenUpdate(oEvent) {
            const aRemovedKeys = (oEvent.getParameter("removedTokens") || []).map((oToken) => oToken.getKey());

            if (!aRemovedKeys.length) {
                return;
            }

            const oModel = this.getView().getModel("emailDraft");
            const aTokens = (oModel.getProperty("/toTokens") || [])
                .filter((oToken) => !aRemovedKeys.includes(oToken.email));

            this._setEmailToTokens(aTokens);
        },

        async onSendRequestEmail() {
            const oEmail = this.getView().getModel("emailDraft").getData();

            if (!oEmail.toRecipients || !oEmail.body) {
                MessageBox.warning(this.getText("requestEmailRequiredMessage"));
                return;
            }

            const aAttachmentIds = (oEmail.attachments || [])
                .filter((oAttachment) => oAttachment.include)
                .map((oAttachment) => oAttachment.ID);

            this.showBusy();

            try {
                const oResult = await this.callAction("sendRequestEmail", {
                    requestId: this._sSelectedRequestId,
                    toRecipients: oEmail.toRecipients,
                    ccRecipients: oEmail.ccRecipients,
                    subject: oEmail.subject,
                    body: oEmail.body,
                    attachmentIds: JSON.stringify(aAttachmentIds)
                });
                const oValue = oResult.value || oResult;

                this.byId("requestEmailDialog").close();
                MessageToast.show(this.getText("requestEmailQueuedMessage", [oValue.attachmentCount || 0]));
                this._refreshEmailSection();
                this._refreshHistorySection();
            } catch (oError) {
                MessageBox.error(this.getErrorMessage(oError, this.getText("requestEmailQueueErrorMessage")));
            } finally {
                this.hideBusy();
            }
        },

        async onOpenAddTaskDialog() {
            if (!this._sSelectedRequestId) {
                MessageToast.show(this.getText("selectRequestMessage"));
                return;
            }

            const oTaskModel = this.getView().getModel("newTask");
            oTaskModel.setData(this._createEmptyTask());

            const oContext = this.byId("requestObjectPage")?.getBindingContext();
            const sSubProcessTypeCode = oContext?.getProperty("subProcessType_code");
            const iCurrentStepNo = Number(oContext?.getProperty("currentStep") || 0);

            if (sSubProcessTypeCode) {
                try {
                    const aSteps = await this._readList("/ProcessStepConfig", {
                        filters: [new Filter("subProcessType_code", FilterOperator.EQ, sSubProcessTypeCode)]
                    });
                    const aStepItems = aSteps
                        .sort((oLeft, oRight) => Number(oLeft.stepNo || 0) - Number(oRight.stepNo || 0))
                        .filter((oStep) => Number(oStep.stepNo || 0) <= iCurrentStepNo)
                        .map((oStep) => ({
                            stepNo: String(oStep.stepNo),
                            text: this.getText("sendBackStepOptionText", [oStep.stepNo, oStep.stepName || ""])
                        }));

                    oTaskModel.setProperty("/steps", aStepItems);
                    oTaskModel.setProperty("/stepNo", aStepItems[0]?.stepNo || "");
                } catch (oError) {
                    MessageToast.show(this.getText("sendBackStepsLoadErrorMessage"));
                }
            }

            this.byId("addTaskDialog").open();
        },

        onAddTaskCancel() {
            this.byId("addTaskDialog").close();
        },

        async onAddTaskConfirm() {
            const oTask = this.getView().getModel("newTask").getData();

            if (!oTask.taskName || !oTask.stepNo) {
                MessageBox.warning(this.getText("taskRequiredMessage"));
                return;
            }

            this.showBusy();

            try {
                const iStepNo = Number(oTask.stepNo);

                await this.createEntry("/ProcessTasks", {
                    request_ID: this._sSelectedRequestId,
                    stepNo: iStepNo,
                    taskName: oTask.taskName,
                    processorUser_ID: oTask.processorUser_ID || undefined,
                    processorTeam_ID: oTask.processorTeam_ID || undefined,
                    processor: oTask.processor,
                    processorEmail: oTask.processorEmail,
                    role: oTask.role,
                    isMandatory: Boolean(oTask.isMandatory),
                    status_code: "OPEN"
                });

                this.byId("addTaskDialog").close();
                MessageToast.show(this.getText("taskCreatedMessage"));
                this._refreshAfterTaskChange(iStepNo);
            } catch (oError) {
                MessageBox.error(this.getErrorMessage(oError, this.getText("taskCreateErrorMessage")));
            } finally {
                this.hideBusy();
            }
        },
        _createEmptyDemandAssignee() {
            return {
                processorUser_ID: "",
                processor: "",
                processorEmail: "",
                processorTeam_ID: "",
                isMandatory: false
            };
        },

        _demandTaskAssignment(oData) {
            return {
                isMandatory: Boolean(oData.isMandatory),
                processorUser_ID: oData.processorUser_ID || undefined,
                processorTeam_ID: oData.processorTeam_ID || undefined,
                processor: oData.processor || undefined,
                processorEmail: oData.processorEmail || undefined
            };
        },

        _demandAssigneeText(oData) {
            return oData.processorTeamName || oData.processorName || "";
        },


    async _getCurrentUserActor() {
        
        try {
            const oResponse = await this.callAction("getCurrentUserDetails");
            const oUser = oResponse.value || oResponse;

            this._sCurrentUserActor = oUser?.email || oUser?.displayName || oUser?.userPrincipalName || "";
        } catch (oError) {
            this._sCurrentUserActor = "";
        }

        return this._sCurrentUserActor;
    },    
    async _updateDemandTaskVisibility(oRequest) {
    const oViewDemandTasks = this.getView().getModel("viewDemandTasks");
    const oVisibility = {
        showTreasuryConfirmation: false,
        showWhtClearance: false,
        showBudgetCheck: false
    };

    const sSubProcessTypeCode = oRequest?.subProcessType_code;
    const iCurrentStep = Number(oRequest?.currentStep);

    if (!sSubProcessTypeCode || !Number.isInteger(iCurrentStep) || iCurrentStep <= 0) {
        oViewDemandTasks.setData(oVisibility);
        return;
    }

    try {
        const aConfigs = await this._readList("/ProcessStepConfig", {
            filters: [
                new Filter("subProcessType_code", FilterOperator.EQ, sSubProcessTypeCode),
                new Filter("stepNo", FilterOperator.EQ, iCurrentStep)
            ]
        });

        const bActive = aConfigs.some((oConfig) => this._isTruthy(oConfig.isActiveDemandTask));

        oVisibility.showTreasuryConfirmation = bActive;
        oVisibility.showWhtClearance = bActive;
        oVisibility.showBudgetCheck = bActive;
    } catch (oError) {
        // Fail closed: no demand-task buttons if config can't be read
    }

    oViewDemandTasks.setData(oVisibility);
},
        _createEmptyTreasuryConfirmation() {
            return {
                treasuryEntity_code: "",
                debitAccountName: "",
                debitAccountNumber: "",
                beneficiary: "",
                treasuryCurrency_code: "",
                treasuryAmount: null,
                treasuryDueDate: null,
                treasuryUserDivisionRep: "",
                ...this._createEmptyDemandAssignee()
            };
        },

      onOpenTreasuryConfirmationDialog() {
            if (!this._sSelectedRequestId) {
                MessageToast.show(this.getText("selectRequestMessage"));
                return;
            }

            const oRequest = this.byId("requestObjectPage").getBindingContext()?.getObject() || {};

            this.getView().getModel("treasuryConfirmation").setData({
                treasuryEntity_code: oRequest.treasuryEntity_code || "",
                debitAccountName: oRequest.debitAccountName || "",
                debitAccountNumber: oRequest.debitAccountNumber || "",
                beneficiary: oRequest.beneficiary || "",
                treasuryCurrency_code: oRequest.treasuryCurrency_code || "",
                treasuryAmount: oRequest.treasuryAmount ?? null,
                treasuryDueDate: oRequest.treasuryDueDate ?? null,
                treasuryUserDivisionRep: oRequest.treasuryUserDivisionRep || "",
                ...this._createEmptyDemandAssignee()
            });
            this.byId("treasuryConfirmationDialog").open();
        },

        onTreasuryConfirmationCancel() {
            this.byId("treasuryConfirmationDialog").close();
        },

        async onTreasuryConfirmationConfirm() {
            const oData = this.getView().getModel("treasuryConfirmation").getData();
            const aMissing = [
                "treasuryEntity_code", "debitAccountName", "debitAccountNumber",
                "beneficiary", "treasuryCurrency_code", "treasuryAmount", "treasuryDueDate", "treasuryUserDivisionRep"
            ].filter((sField) => !this._hasFormValue(oData[sField]));

            if (aMissing.length) {
                MessageBox.warning(this.getText("treasuryConfirmationRequiredMessage"));
                return;
            }
            if (!oData.processorUser_ID && !oData.processorTeam_ID) {
                MessageBox.warning(this.getText("selectProcessorOrTeamMessage"));
                return;
            }

            this.showBusy();

            try {
                const oRequest = this.byId("requestObjectPage").getBindingContext()?.getObject() || {};
                const iStepNo = oRequest.currentStep;

                if (!oRequest.reservedBy) {
                    MessageBox.warning(this.getText("reserveRequestFirstMessage"));
                    return;
                }

                if (!Number.isInteger(Number(iStepNo)) || Number(iStepNo) <= 0) {
                    MessageBox.warning(this.getText("noActiveStepMessage"));
                    return;
                }

                const fAmount = Number(oData.treasuryAmount);
                if (!Number.isFinite(fAmount)) {
                    MessageBox.warning(this.getText("invalidAmountMessage"));
                    return;
                }
                const aExistingTasks = await this._readList("/ProcessTasks", {
                    filters: [
                        new Filter("request_ID", FilterOperator.EQ, this._sSelectedRequestId),
                        new Filter("stepNo", FilterOperator.EQ, iStepNo),
                        new Filter("taskName", FilterOperator.EQ, "Treasury Confirmation")
                    ]
                });
                if (aExistingTasks.some((oTask) => this._isOpenLikeTask(oTask))) {
                    MessageBox.error(this.getText("treasuryTaskAlreadyExistsMessage"));
                    return;
                }

                // const aTeams = await this._readList("/Teams", {
                //     filters: [
                //         new Filter("teamCode", FilterOperator.EQ, "TREASURY"),
                //         new Filter("isActive", FilterOperator.EQ, true)
                //     ]
                // });
                // const oTreasuryTeam = aTeams[0];
                // if (!oTreasuryTeam) {
                //     MessageBox.error(this.getText("noTreasuryTeamMessage"));
                //     return;
                // }

                await this.updateEntry(`/ProcessRequests(${this._sSelectedRequestId})`, {
                    treasuryEntity_code: oData.treasuryEntity_code,
                    debitAccountName: oData.debitAccountName,
                    debitAccountNumber: oData.debitAccountNumber,
                    beneficiary: oData.beneficiary,
                    treasuryCurrency_code: oData.treasuryCurrency_code,
                    treasuryAmount: fAmount,
                    treasuryDueDate: oData.treasuryDueDate,
                    treasuryUserDivisionRep: oData.treasuryUserDivisionRep
                });

                // referenceNumber, processorTeamName, isTeamTask, team-member sync,
                // team notification, and the parent request's SLA/currentStep refresh
                // all happen automatically via the ProcessTasks before/after CREATE hooks
                await this.createEntry("/ProcessTasks", {
                    request_ID: this._sSelectedRequestId,
                    stepNo: iStepNo,
                    taskName: "Treasury Confirmation",
                    // processorTeam_ID: oTreasuryTeam.ID,
                    ...this._demandTaskAssignment(oData),
                    status_code: "OPEN"
                });

                // Not written automatically outside the custom action - add it explicitly
                const sActor = await this._getCurrentUserActor();
                await this.createEntry("/ProcessHistory", {
                    request_ID: this._sSelectedRequestId,
                    stepNo: iStepNo,
                    action: "TREASURY_CONFIRMATION_CREATED",
                    actor: sActor,
                    oldStatus: oRequest.status_code,
                    newStatus: oRequest.status_code,
                    remarks: `Treasury confirmation submitted; Treasury task created at step ${iStepNo} and assigned to ${this._demandAssigneeText(oData)}`
                });

                this.byId("treasuryConfirmationDialog").close();
                MessageToast.show(this.getText("treasuryConfirmationCreatedMessage"));
                this._refreshRequestHeader();
                this._refreshTaskSection();
                this._refreshHistorySection();
                this._refreshProcessFlow();
            } catch (oError) {
                MessageBox.error(this.getErrorMessage(oError, this.getText("treasuryConfirmationCreateErrorMessage")));
            } finally {
                this.hideBusy();
            }
        },

        _isOpenLikeTask(oTask) {
            const sStatus = String(oTask?.status_code?.code || oTask?.status_code || "").toUpperCase();
            return sStatus === "OPEN" || sStatus === "SENT_BACK";
        },

        _hasFormValue(vValue) {
            return vValue !== null && vValue !== undefined && String(vValue).trim() !== "";
        },

        _createEmptyWhtClearance() {
            return {
                whtEntity_code: "",
                whtVendor: "",
                whtCurrency_code: "",
                whtAmount: null,
                whtDueDate: null,
                whtUserDivisionRep: "",
                ...this._createEmptyDemandAssignee()
            };
        },

        onOpenWhtClearanceDialog() {
            if (!this._sSelectedRequestId) {
                MessageToast.show(this.getText("selectRequestMessage"));
                return;
            }

            const oRequest = this.byId("requestObjectPage").getBindingContext()?.getObject() || {};

            // Autofill from whatever the request already has
            this.getView().getModel("whtClearance").setData({
                whtEntity_code: oRequest.whtEntity_code || "",
                whtVendor: oRequest.whtVendor || "",
                whtCurrency_code: oRequest.whtCurrency_code || "",
                whtAmount: oRequest.whtAmount ?? null,
                whtDueDate: oRequest.whtDueDate ?? null,
                whtUserDivisionRep: oRequest.whtUserDivisionRep || "",
                ...this._createEmptyDemandAssignee()
            });
            this.byId("whtClearanceDialog").open();
        },

        onWhtClearanceCancel() {
            this.byId("whtClearanceDialog").close();
        },

        async onWhtClearanceConfirm() {
            const oData = this.getView().getModel("whtClearance").getData();
            const aMissing = [
                "whtEntity_code", "whtVendor", "whtCurrency_code",
                "whtAmount", "whtDueDate", "whtUserDivisionRep"
            ].filter((sField) => !this._hasFormValue(oData[sField]));

            if (aMissing.length) {
                MessageBox.warning(this.getText("whtClearanceRequiredMessage"));
                return;
            }
             if (!oData.processorUser_ID && !oData.processorTeam_ID) {
                MessageBox.warning(this.getText("selectProcessorOrTeamMessage"));
                return;
            }

            this.showBusy();

            try {
                const oRequest = this.byId("requestObjectPage").getBindingContext()?.getObject() || {};
                const iStepNo = oRequest.currentStep;

                if (!oRequest.reservedBy) {
                    MessageBox.warning(this.getText("reserveRequestFirstMessage"));
                    return;
                }

                if (!Number.isInteger(Number(iStepNo)) || Number(iStepNo) <= 0) {
                    MessageBox.warning(this.getText("noActiveStepMessage"));
                    return;
                }

                const fAmount = Number(oData.whtAmount);
                if (!Number.isFinite(fAmount)) {
                    MessageBox.warning(this.getText("invalidAmountMessage"));
                    return;
                }

                const aExistingTasks = await this._readList("/ProcessTasks", {
                    filters: [
                        new Filter("request_ID", FilterOperator.EQ, this._sSelectedRequestId),
                        new Filter("stepNo", FilterOperator.EQ, iStepNo),
                        new Filter("taskName", FilterOperator.EQ, "WHT Clearance")
                    ]
                });
                if (aExistingTasks.some((oTask) => this._isOpenLikeTask(oTask))) {
                    MessageBox.error(this.getText("whtTaskAlreadyExistsMessage"));
                    return;
                }
                // const aTeams = await this._readList("/Teams", {
                //     filters: [
                //         new Filter("teamCode", FilterOperator.EQ, "TAX"),
                //         new Filter("isActive", FilterOperator.EQ, true)
                //     ]
                // });
                // const oTaxTeam = aTeams[0];
                // if (!oTaxTeam) {
                //     MessageBox.error(this.getText("noTaxTeamMessage"));
                //     return;
                // }

                await this.updateEntry(`/ProcessRequests(${this._sSelectedRequestId})`, {
                    whtEntity_code: oData.whtEntity_code,
                    whtVendor: oData.whtVendor,
                    whtCurrency_code: oData.whtCurrency_code,
                    whtAmount: fAmount,
                    whtDueDate: oData.whtDueDate,
                    whtUserDivisionRep: oData.whtUserDivisionRep
                });

                await this.createEntry("/ProcessTasks", {
                    request_ID: this._sSelectedRequestId,
                    stepNo: iStepNo,
                    taskName: "WHT Clearance",
                    // processorTeam_ID: oTaxTeam.ID,
                    ...this._demandTaskAssignment(oData),
                    status_code: "OPEN"
                });
                const sActor = await this._getCurrentUserActor();
                await this.createEntry("/ProcessHistory", {
                    request_ID: this._sSelectedRequestId,
                    stepNo: iStepNo,
                    action: "WHT_CLEARANCE_CREATED",
                    actor: sActor,
                    oldStatus: oRequest.status_code,
                    newStatus: oRequest.status_code,
                    remarks: `WHT clearance requested; Tax task created at step ${iStepNo} and assigned to ${this._demandAssigneeText(oData)}`
                });

                this.byId("whtClearanceDialog").close();
                MessageToast.show(this.getText("whtClearanceCreatedMessage"));
                this._refreshRequestHeader();
                this._refreshTaskSection();
                this._refreshHistorySection();
                this._refreshProcessFlow();
            } catch (oError) {
                MessageBox.error(this.getErrorMessage(oError, this.getText("whtClearanceCreateErrorMessage")));
            } finally {
                this.hideBusy();
            }
        },
        onOpenBudgetCheckDialog() {
    if (!this._sSelectedRequestId) {
        MessageToast.show(this.getText("selectRequestMessage"));
        return;
    }

    this.getView().getModel("budgetCheck").setData(this._createEmptyDemandAssignee());
    this.byId("budgetCheckDialog").open();
},

onBudgetCheckCancel() {
    this.byId("budgetCheckDialog").close();
},

async onBudgetCheckConfirm() {
    const oData = this.getView().getModel("budgetCheck").getData();

    if (!oData.processorUser_ID && !oData.processorTeam_ID) {
        MessageBox.warning(this.getText("selectProcessorOrTeamMessage"));
        return;
    }

    this.showBusy();

    try {
        const oRequest = this.byId("requestObjectPage").getBindingContext()?.getObject() || {};
        const iStepNo = Number(oRequest.currentStep);

        if (!oRequest.reservedBy) {
            MessageBox.warning(this.getText("reserveRequestFirstMessage"));
            return;
        }

        if (!Number.isInteger(iStepNo) || iStepNo <= 0) {
            MessageBox.warning(this.getText("noActiveStepMessage"));
            return;
        }

        const aExistingTasks = await this._readList("/ProcessTasks", {
            filters: [
                new Filter("request_ID", FilterOperator.EQ, this._sSelectedRequestId),
                new Filter("stepNo", FilterOperator.EQ, iStepNo),
                new Filter("taskName", FilterOperator.EQ, "Budget Check")
            ]
        });

        if (aExistingTasks.some((oTask) => this._isOpenLikeTask(oTask))) {
            MessageBox.error(this.getText("budgetTaskAlreadyExistsMessage"));
            return;
        }

        await this.createEntry("/ProcessTasks", {
            request_ID: this._sSelectedRequestId,
            stepNo: iStepNo,
            taskName: "Budget Check",
            ...this._demandTaskAssignment(oData),
            status_code: "OPEN"
        });

        const sActor = await this._getCurrentUserActor();
        await this.createEntry("/ProcessHistory", {
            request_ID: this._sSelectedRequestId,
            stepNo: iStepNo,
            action: "BUDGET_CHECK_CREATED",
            actor: sActor,
            oldStatus: oRequest.status_code,
            newStatus: oRequest.status_code,
            remarks: `Budget Check task created at step ${iStepNo} and assigned to ${this._demandAssigneeText(oData)}`
        });

        this.byId("budgetCheckDialog").close();
        MessageToast.show(this.getText("budgetCheckCreatedMessage"));
        this._refreshRequestHeader();
        this._refreshTaskSection();
        this._refreshHistorySection();
        this._refreshProcessFlow();
    } catch (oError) {
        MessageBox.error(this.getErrorMessage(oError, this.getText("budgetCheckCreateErrorMessage")));
    } finally {
        this.hideBusy();
    }
},
        onDemandProcessorValueHelpRequest(oEvent) {
            this._sProcessorValueHelpTarget = oEvent.getSource().data("target");
            this.byId("myRequestsProcessorValueHelpDialog").open();
        },

        onDemandTeamValueHelpRequest(oEvent) {
            this._sTeamValueHelpTarget = oEvent.getSource().data("target");
            this.byId("myRequestsTeamValueHelpDialog").open();
        },

        onDemandProcessorSuggestionSelected(oEvent) {
            this._applyProcessorSelection(this._getSuggestionContext(oEvent), oEvent.getSource().data("target"));
        },

        onDemandTeamSuggestionSelected(oEvent) {
            this._applyTeamSelection(this._getSuggestionContext(oEvent), oEvent.getSource().data("target"));
        },

        onDemandProcessorLiveChange(oEvent) {
            const oModel = this.getView().getModel(DEMAND_TASK_MODELS[oEvent.getSource().data("target")]);
            oModel.setProperty("/processorUser_ID", "");
            oModel.setProperty("/processor", "");
            oModel.setProperty("/processorEmail", "");
        },

        onDemandTeamLiveChange(oEvent) {
            this.getView().getModel(DEMAND_TASK_MODELS[oEvent.getSource().data("target")])
                .setProperty("/processorTeam_ID", "");
        },
        onOpenAddPartyDialog() {
            if (!this._sSelectedRequestId) {
                MessageToast.show(this.getText("selectRequestMessage"));
                return;
            }

            this.getView().getModel("newParty").setData(this._createEmptyParty());
            this.byId("addPartyDialog").open();
        },

        onAddPartyCancel() {
            this.byId("addPartyDialog").close();
        },

        onPartyValueHelpRequest() {
            this.byId("involvedPartyValueHelpDialog").open();
        },

        onPartySuggestionSelected(oEvent) {
            this._applyPartySelection(this._getSuggestionContext(oEvent));
        },

        onPartyLiveChange() {
            const oModel = this.getView().getModel("newParty");
            oModel.setProperty("/user_ID", "");
            oModel.setProperty("/email", "");
            oModel.setProperty("/department", "");
        },

        onPartyValueHelpSearch(oEvent) {
            this._filterUsers(oEvent.getSource(), oEvent.getParameter("value") || "");
        },

        onPartyValueHelpConfirm(oEvent) {
            const oContext = oEvent.getParameter("selectedItem")?.getBindingContext();

            this._applyPartySelection(oContext);

            this.onPartyValueHelpClose(oEvent);
        },

        onPartyValueHelpClose(oEvent) {
            oEvent.getSource().getBinding("items")?.filter([]);
        },

        async onAddPartyConfirm() {
            const oParty = this.getView().getModel("newParty").getData();

            if (!oParty.user_ID) {
                MessageBox.warning(this.getText("selectPartyMessage"));
                return;
            }

            this.showBusy();

            try {
                await this.createEntry("/ProcessInvolvedParties", {
                    request_ID: this._sSelectedRequestId,
                    user_ID: oParty.user_ID,
                    purpose: oParty.purpose
                });
                this.byId("addPartyDialog").close();
                MessageToast.show(this.getText("partyCreatedMessage"));
                this._refreshPartySection();
            } catch (oError) {
                MessageBox.error(this.getErrorMessage(oError, this.getText("partyCreateErrorMessage")));
            } finally {
                this.hideBusy();
            }
        },

        async onNotifyInvolvedParty(oEvent) {
            oEvent.cancelBubble?.();

            const oContext = oEvent.getSource().getBindingContext();
            const sPartyId = oContext && oContext.getProperty("ID");

            if (!sPartyId) {
                MessageToast.show(this.getText("selectPartyMessage"));
                return;
            }

            this.showBusy();

            try {
                const oRecipient = await this.callAction("resolveInvolvedPartyNotificationRecipient", {
                    partyId: sPartyId
                });
                const sRequestTitle = oContext.getProperty("request/title")
                    || this.byId("requestObjectPage").getBindingContext()?.getProperty("title")
                    || "";
                const sPurpose = oContext.getProperty("purpose") || "";
                const sSubject = this.getText("partyNotificationSubject", [sRequestTitle]);
                const sBody = this.getText("partyNotificationBody", [sRequestTitle, sPurpose, window.location.href]);

                if (oRecipient.delegated) {
                    MessageToast.show(this.getText("notificationDelegatedMessage", [oRecipient.recipient]));
                }

                window.location.href = `mailto:${encodeURIComponent(oRecipient.recipient)}?subject=${encodeURIComponent(sSubject)}&body=${encodeURIComponent(sBody)}`;
            } catch (oError) {
                MessageBox.error(this.getErrorMessage(oError, this.getText("partyEmailMissingMessage")));
            } finally {
                this.hideBusy();
            }
        },

        async onDeleteParty(oEvent) {
            oEvent.cancelBubble?.();

            const sPartyId = oEvent.getSource().getBindingContext()?.getProperty("ID");

            if (!sPartyId || !await this._confirmDelete("deletePartyConfirmMessage")) {
                return;
            }

            this.showBusy();

            try {
                await this.removeEntry(`/ProcessInvolvedParties(guid'${sPartyId}')`);
                MessageToast.show(this.getText("partyDeletedMessage"));

                if (this._sSelectedPartyId === sPartyId) {
                    this._sSelectedPartyId = null;
                    this.onCloseInvolvedPartyDetail();
                }

                this._refreshPartySection();
            } catch (oError) {
                MessageBox.error(this.getErrorMessage(oError, this.getText("partyDeleteErrorMessage")));
            } finally {
                this.hideBusy();
            }
        },

        async onDeleteSelectedParties() {
            const oTable = this.byId("requestPartiesTable");
            const aIds = oTable.getSelectedContexts().map((oContext) => oContext.getProperty("ID"));

            if (!aIds.length) {
                MessageToast.show(this.getText("selectItemsToDeleteMessage"));
                return;
            }

            if (!await this._confirmDelete("deleteSelectedPartiesConfirmMessage", [aIds.length])) {
                return;
            }

            this.showBusy();

            try {
                await Promise.all(aIds.map((sId) => this.removeEntry(`/ProcessInvolvedParties(guid'${sId}')`)));
                MessageToast.show(this.getText("selectedPartiesDeletedMessage", [aIds.length]));

                if (aIds.includes(this._sSelectedPartyId)) {
                    this._sSelectedPartyId = null;
                    this.onCloseInvolvedPartyDetail();
                }

                oTable.removeSelections(true);
                this._refreshPartySection();
            } catch (oError) {
                MessageBox.error(this.getErrorMessage(oError, this.getText("partyDeleteErrorMessage")));
            } finally {
                this.hideBusy();
            }
        },

        async onRequestAttachmentsSelected(oEvent) {
            const aFiles = Array.from(oEvent.getParameter("files") || []);

            oEvent.getSource().clear();

            if (!this._validateAttachmentFiles(aFiles)) {
                return;
            }

            if (!this._sSelectedRequestId) {
                MessageToast.show(this.getText("selectRequestMessage"));
                return;
            }

            if (!aFiles.length) {
                return;
            }

            this._startAttachmentUploads(aFiles);

            try {
                await this._uploadAttachments(this._sSelectedRequestId, aFiles);
                MessageToast.show(this.getText("attachmentsUploadedMessage"));
                this._refreshAttachmentSection();
            } catch (oError) {
                MessageBox.error(this.getErrorMessage(oError, this.getText("attachmentContentErrorMessage", [""])));
            } finally {
                this.getView().getModel("uploads").setProperty("/active", false);
            }
        },

        onAttachmentFileSizeExceed(oEvent) {
            MessageBox.warning(this.getText("attachmentSizeExceededMessage", [
                oEvent.getParameter("fileName"),
                MAX_ATTACHMENT_SIZE_MB
            ]));
            oEvent.getSource().clear();
        },

        async onViewAttachment(oEvent) {
            oEvent.cancelBubble?.();

            const oContext = oEvent.getSource().getBindingContext();

            this.showBusy();

            try {
                const oFile = await this._fetchAttachmentContent(oContext);
                const sUrl = URL.createObjectURL(oFile.blob);

                window.open(sUrl, "_blank", "noopener,noreferrer");
                setTimeout(() => URL.revokeObjectURL(sUrl), 60000);
            } catch (oError) {
                MessageBox.error(this.getErrorMessage(oError, this.getText("attachmentOpenErrorMessage")));
            } finally {
                this.hideBusy();
            }
        },

        onAttachmentReferencePress(oEvent) {
            oEvent.cancelBubble?.();
            this.onViewAttachment(oEvent);
        },

        async onDownloadAttachment(oEvent) {
            oEvent.cancelBubble?.();

            const oContext = oEvent.getSource().getBindingContext();

            this.showBusy();

            try {
                const oFile = await this._fetchAttachmentContent(oContext);
                const sUrl = URL.createObjectURL(oFile.blob);
                const oLink = document.createElement("a");

                oLink.href = sUrl;
                oLink.download = oFile.filename;
                document.body.appendChild(oLink);
                oLink.click();
                document.body.removeChild(oLink);
                URL.revokeObjectURL(sUrl);
            } catch (oError) {
                MessageBox.error(this.getErrorMessage(oError, this.getText("attachmentDownloadErrorMessage")));
            } finally {
                this.hideBusy();
            }
        },

        async onDeleteRequestTask(oEvent) {
            
            oEvent.cancelBubble?.();

            const oContext = oEvent.getSource().getBindingContext();
            const sTaskId = oContext && oContext.getProperty("ID");

            if (!sTaskId) {
                MessageToast.show(this.getText("selectTaskMessage"));
                return;
            }

            if (this._isTruthy(oContext.getProperty("isMandatory"))) {
                MessageBox.warning(this.getText("mandatoryTaskDeleteBlockedMessage"));
                return;
            }

            const bConfirmed = await this._confirmDelete("deleteTaskConfirmMessage");

            if (!bConfirmed) {
                return;
            }

            this.showBusy();

            try {
                await this.removeEntry(`/ProcessTasks(guid'${sTaskId}')`);
                MessageToast.show(this.getText("taskDeletedMessage"));

                if (this._sSelectedTaskId === sTaskId) {
                    this._sSelectedTaskId = null;
                    this.onCloseRequestTaskDetail();
                }

                this._refreshAfterTaskChange();
                this.byId("requestsTable").getBinding("items").refresh();
            } catch (oError) {
                MessageBox.error(this.getErrorMessage(oError, this.getText("taskDeleteErrorMessage")));
            } finally {
                this.hideBusy();
            }
        },

        async onDeleteSelectedRequestTasks() {
            const oTable = this.byId("requestTasksTable");
            const aSelectedContexts = oTable.getSelectedContexts();
            const aTaskIds = aSelectedContexts.map((oContext) => oContext.getProperty("ID"));

            if (!aTaskIds.length) {
                MessageToast.show(this.getText("selectItemsToDeleteMessage"));
                return;
            }

            if (aSelectedContexts.some((oContext) => this._isTruthy(oContext.getProperty("isMandatory")))) {
                MessageBox.warning(this.getText("mandatoryTaskDeleteBlockedMessage"));
                return;
            }

            const bConfirmed = await this._confirmDelete("deleteSelectedTasksConfirmMessage", [aTaskIds.length]);

            if (!bConfirmed) {
                return;
            }

            this.showBusy();

            try {
                await Promise.all(aTaskIds.map((sTaskId) => this.removeEntry(`/ProcessTasks(guid'${sTaskId}')`)));
                MessageToast.show(this.getText("selectedTasksDeletedMessage", [aTaskIds.length]));

                if (aTaskIds.includes(this._sSelectedTaskId)) {
                    this._sSelectedTaskId = null;
                    this.onCloseRequestTaskDetail();
                }

                oTable.removeSelections(true);
                this._refreshAfterTaskChange();
                this.byId("requestsTable").getBinding("items").refresh();
            } catch (oError) {
                MessageBox.error(this.getErrorMessage(oError, this.getText("taskDeleteErrorMessage")));
            } finally {
                this.hideBusy();
            }
        },

        async onDeleteRequest(oEvent) {
            oEvent.cancelBubble?.();

            const oContext = oEvent.getSource().getBindingContext();
            const sRequestId = oContext && oContext.getProperty("ID");

            if (!sRequestId) {
                MessageToast.show(this.getText("selectRequestMessage"));
                return;
            }

            if (!this._canCurrentUserModifyRequest(oContext.getObject())) {
                MessageBox.warning(this.getText("requestNotEditableMessage"));
                return;
            }

            const bConfirmed = await this._confirmDelete("deleteRequestConfirmMessage");

            if (!bConfirmed) {
                return;
            }

            this.showBusy();

            try {
                await this.removeEntry(`/ProcessRequests(guid'${sRequestId}')`);
                MessageToast.show(this.getText("requestDeletedMessage"));

                if (this._sSelectedRequestId === sRequestId) {
                    this._sSelectedRequestId = null;
                    this._sSelectedTaskId = null;
                    this._setRequestsLayout(fLibrary.LayoutType.OneColumn);
                }

                this.byId("requestsTable").getBinding("items").refresh();
            } catch (oError) {
                MessageBox.error(this.getErrorMessage(oError, this.getText("requestDeleteErrorMessage")));
            } finally {
                this.hideBusy();
            }
        },

        async onDeleteSelectedRequests() {
            const oTable = this.byId("requestsTable");
            const aSelectedContexts = oTable.getSelectedContexts();
            const aRequestIds = aSelectedContexts.map((oContext) => oContext.getProperty("ID"));

            if (!aRequestIds.length) {
                MessageToast.show(this.getText("selectItemsToDeleteMessage"));
                return;
            }

            if (aSelectedContexts.some((oContext) => !this._canCurrentUserModifyRequest(oContext.getObject()))) {
                MessageBox.warning(this.getText("requestNotEditableMessage"));
                return;
            }

            const bConfirmed = await this._confirmDelete("deleteSelectedRequestsConfirmMessage", [aRequestIds.length]);

            if (!bConfirmed) {
                return;
            }

            this.showBusy();

            try {
                await Promise.all(aRequestIds.map((sRequestId) => this.removeEntry(`/ProcessRequests(guid'${sRequestId}')`)));
                MessageToast.show(this.getText("selectedRequestsDeletedMessage", [aRequestIds.length]));

                if (aRequestIds.includes(this._sSelectedRequestId)) {
                    this._sSelectedRequestId = null;
                    this._sSelectedTaskId = null;
                    this._setRequestsLayout(fLibrary.LayoutType.OneColumn);
                }

                oTable.removeSelections(true);
                oTable.getBinding("items").refresh();
            } catch (oError) {
                MessageBox.error(this.getErrorMessage(oError, this.getText("requestDeleteErrorMessage")));
            } finally {
                this.hideBusy();
            }
        },

        async onDeleteAttachment(oEvent) {
            oEvent.cancelBubble?.();

            const oContext = oEvent.getSource().getBindingContext();
            const sAttachmentId = oContext && oContext.getProperty("ID");

            if (!sAttachmentId) {
                return;
            }

            const bConfirmed = await this._confirmDelete("deleteAttachmentConfirmMessage");

            if (!bConfirmed) {
                return;
            }

            this.showBusy();

            try {
                await this.removeEntry(`/ProcessAttachments(guid'${sAttachmentId}')`);
                MessageToast.show(this.getText("attachmentDeletedMessage"));
                this._refreshAttachmentSection();
            } catch (oError) {
                MessageBox.error(this.getErrorMessage(oError, this.getText("attachmentDeleteErrorMessage")));
            } finally {
                this.hideBusy();
            }
        },

        async onDeleteSelectedAttachments() {
            const oTable = this.byId("requestAttachmentsTable");
            const aAttachmentIds = oTable.getSelectedContexts().map((oContext) => oContext.getProperty("ID"));

            if (!aAttachmentIds.length) {
                MessageToast.show(this.getText("selectItemsToDeleteMessage"));
                return;
            }

            const bConfirmed = await this._confirmDelete("deleteSelectedAttachmentsConfirmMessage", [aAttachmentIds.length]);

            if (!bConfirmed) {
                return;
            }

            this.showBusy();

            try {
                await Promise.all(aAttachmentIds.map((sAttachmentId) => this.removeEntry(`/ProcessAttachments(guid'${sAttachmentId}')`)));
                MessageToast.show(this.getText("selectedAttachmentsDeletedMessage", [aAttachmentIds.length]));
                oTable.removeSelections(true);
                this._refreshAttachmentSection();
            } catch (oError) {
                MessageBox.error(this.getErrorMessage(oError, this.getText("attachmentDeleteErrorMessage")));
            } finally {
                this.hideBusy();
            }
        },

        formatPriorityHighlight(sPriority) {
            switch ((sPriority || "").toLowerCase()) {
                case "critical":
                    return "Error";
                case "high":
                    return "Warning";
                case "medium":
                    return "Information";
                case "low":
                    return "Success";
                default:
                    return "None";
            }
        },

        formatPriorityState(sPriority) {
            switch ((sPriority || "").toLowerCase()) {
                case "critical":
                    return "Error";
                case "high":
                    return "Warning";
                case "medium":
                    return "Information";
                case "low":
                    return "Success";
                default:
                    return "None";
            }
        },

        _addUnreservedQueueFilters(aFilters) {
            const oFilterData = this._getUnreservedQueueFilterData();

            if (oFilterData.processType_code) {
                aFilters.push(new Filter("processType_code", FilterOperator.EQ, oFilterData.processType_code));
            }

            if (oFilterData.subProcessType_code) {
                aFilters.push(new Filter("subProcessType_code", FilterOperator.EQ, oFilterData.subProcessType_code));
            }
        },

        _getUnreservedQueueFilterData() {
            return {
                processType_code: this.byId("unreservedProcessTypeFilter")?.getSelectedKey()
                    || this.getView().getModel("requestQueueFilter").getProperty("/processType_code")
                    || "",
                subProcessType_code: this.byId("unreservedSubProcessTypeFilter")?.getSelectedKey()
                    || this.getView().getModel("requestQueueFilter").getProperty("/subProcessType_code")
                    || ""
            };
        },

        _syncUnreservedQueueFilterModelFromControls() {
            const oFilterData = this._getUnreservedQueueFilterData();
            const oFilterModel = this.getView().getModel("requestQueueFilter");

            oFilterModel.setProperty("/processType_code", oFilterData.processType_code);
            oFilterModel.setProperty("/subProcessType_code", oFilterData.subProcessType_code);
        },

        async _loadRequestFilterQueries(sSelectedQueryId) {
            try {
                const oData = await new Promise((resolve, reject) => {
                    this.getModel().read("/RequestFilterQueries", {
                        success: resolve,
                        error: reject
                    });
                });
                const aQueries = (oData.results || []).sort((oFirst, oSecond) =>
                    (oFirst.name || "").localeCompare(oSecond.name || "")
                );
                const sSelectedKey = sSelectedQueryId && aQueries.some((oQuery) => oQuery.ID === sSelectedQueryId)
                    ? sSelectedQueryId
                    : "";

                this.getView().getModel("requestQueueQueries").setData({
                    selectedKey: sSelectedKey,
                    items: aQueries
                });
            } catch (oError) {
                MessageToast.show(this.getText("queryLoadErrorMessage"));
            }
        },

        _applyRequestFilterQuery(oQuery) {
            const oFilterModel = this.getView().getModel("requestQueueFilter");
            const sProcessTypeCode = oQuery.processType_code || "";
            const sSubProcessTypeCode = oQuery.subProcessType_code || "";

            oFilterModel.setData({
                processType_code: sProcessTypeCode,
                subProcessType_code: sSubProcessTypeCode,
                search: oQuery.search || ""
            });
            this.byId("unreservedProcessTypeFilter")?.setSelectedKey(sProcessTypeCode);
            this.byId("unreservedSubProcessTypeFilter")?.setSelectedKey(sSubProcessTypeCode);
            this._filterUnreservedSubProcessTypes();
            this._rebindRequestsTable();
        },

        _requestFilterQueryPath(sQueryId) {
            return `/RequestFilterQueries(guid'${sQueryId}')`;
        },

        _addRequestSearchFilter(aFilters) {
            const sQuery = this.getView().getModel("requestQueueFilter").getProperty("/search");

            if (!sQuery) {
                return;
            }

            aFilters.push(new Filter({
                filters: [
                    new Filter("referenceNumber", FilterOperator.Contains, sQuery),
                    new Filter("title", FilterOperator.Contains, sQuery),
                    new Filter("processor", FilterOperator.Contains, sQuery),
                    new Filter("processType_code", FilterOperator.Contains, sQuery),
                    new Filter("processType/name", FilterOperator.Contains, sQuery),
                    new Filter("subProcessType_code", FilterOperator.Contains, sQuery),
                    new Filter("subProcessType/name", FilterOperator.Contains, sQuery),
                    new Filter("status_code", FilterOperator.Contains, sQuery),
                    new Filter("department", FilterOperator.Contains, sQuery),
                    new Filter("priority", FilterOperator.Contains, sQuery)
                ],
                and: false
            }));
        },

        _clearUnreservedQueueFilterState() {
            this.getView().getModel("requestQueueFilter").setData({
                processType_code: "",
                subProcessType_code: "",
                search: ""
            });
            this.getView().getModel("requestQueueQueries")?.setProperty("/selectedKey", "");
            this.byId("unreservedProcessTypeFilter")?.setSelectedKey("");
            this.byId("unreservedSubProcessTypeFilter")?.setSelectedKey("");
        },

        _filterUnreservedSubProcessTypes() {
            const sProcessTypeCode = this.getView().getModel("requestQueueFilter").getProperty("/processType_code");
            const oSubProcessTypeFilter = this.byId("unreservedSubProcessTypeFilter");
            const oBinding = oSubProcessTypeFilter?.getBinding("items");

            if (!oBinding) {
                return;
            }

            oBinding.filter(sProcessTypeCode
                ? [new Filter("processType_code", FilterOperator.EQ, sProcessTypeCode)]
                : []);
        },

        _openRequest(oContext) {
            this._showRequestDetail(oContext);
        },

        _showRequestDetail(oContext) {
            this._showRequestDetailById(oContext.getProperty("ID"));
        },

        _showRequestDetailById(sRequestId) {
            this._sSelectedRequestId = sRequestId;
            this.byId("requestObjectPage").bindElement({
                path: `/ProcessRequests(guid'${sRequestId}')`,
                parameters: {
                    expand: "processType,subProcessType,paymentCategory,businessEntity,predecessor,successors,paymentMethod,typeOfPayment,guaranteeType,paymentSubCategory"
                },
                events: {
                    dataRequested: this.onDataRequested.bind(this),
                    dataReceived: () => {
                        this.onDataReceived();
                        const oRequestContext = this.byId("requestObjectPage").getBindingContext();
                        const oRequest = oRequestContext?.getObject();

                        this.getView().getModel("statusEdit").setProperty(
                            "/requestStatus",
                            oRequest?.status_code || ""
                        );
                        this.getView().getModel("requestEdit").setProperty(
                            "/editable",
                            this._isRequestEditable(oRequest)
                        );
                        this.getView().getModel("processorEdit").setProperty(
                            "/requestProcessorUser_ID",
                            oRequest?.processorUser_ID || ""
                        );
                        this.getView().getModel("processorEdit").setProperty(
                            "/requestProcessorName",
                            oRequest?.processor || ""
                        );
                        this.getView().getModel("processorEdit").setProperty(
                            "/requestTeam_ID",
                            oRequest?.processorTeam_ID || ""
                        );
                        this.getView().getModel("processorEdit").setProperty(
                            "/requestTeamName",
                            oRequest?.processorTeamName || ""
                        );
                        this._updateDemandTaskVisibility(oRequest);
                    }
                }
            });
            this._bindRequestSectionTables(sRequestId);
            const oRequestContext = this.byId("requestObjectPage").getBindingContext();
            const oRequest = oRequestContext?.getObject();
            this._updateDemandTaskVisibility(oRequest);
            this._setRequestsLayout(fLibrary.LayoutType.TwoColumnsMidExpanded);
            this._refreshProcessFlow();
        },

        _setRequestsLayout(sLayout) {
            this.byId("requestsFlexibleColumnLayout").setLayout(sLayout);
            this.getView().getModel("fclState").setData({
                midFullScreen: sLayout === fLibrary.LayoutType.MidColumnFullScreen,
                endFullScreen: sLayout === fLibrary.LayoutType.EndColumnFullScreen
            });
        },

        _bindRequestSectionTables(sRequestId) {
            this._bindRequestSectionTable("requestTasksTable", "/RequestDetailTasks", sRequestId, {
                parameters: {
                    expand: "request"
                }
            });
            this._bindRequestSectionTable("requestPartiesTable", "/ProcessInvolvedParties", sRequestId);
            this._bindRequestSectionTable("requestAttachmentsTable", "/ProcessAttachments", sRequestId);
            this._bindRequestSectionTable("requestHistoryTable", "/ProcessHistory", sRequestId);
            // this._bindRequestSectionTable("requestEmailsTable", "/RequestEmails", sRequestId,{
            //     parameters:{
            //         expand: "attachments"
            //     }
            // });
        },

        _bindRequestSectionTable(sTableId, sPath, sRequestId, oParameters = {}) {
            const oTable = this.byId(sTableId);
            const oBindingInfo = oTable?.getBindingInfo("items");

            if (!oTable || !oBindingInfo?.template) {
                return;
            }

            oTable.bindItems({
                path: sPath,
                template: oBindingInfo.template,
                templateShareable: true,
                filters: [new Filter("request_ID", FilterOperator.EQ, sRequestId)],
                ...(oParameters || {}),
                events: {
                    dataRequested: () => {
                        oTable.setBusyIndicatorDelay(0);
                        oTable.setBusy(true);
                    },
                    dataReceived: () => {
                        oTable.setBusy(false);
                    }
                }
            });
        },

        _getRequestListRouteParameters(oExtraQuery = {}) {
            const oQuery = { ...oExtraQuery };

            if (this._bShowUnreservedOnly) {
                oQuery.unreserved = "true";
            }

            if (this._bShowReservedOnly) {
                oQuery.reserved = "true";
            }

            return Object.keys(oQuery).length
                ? { "?query": oQuery }
                : {};
        },

        _resetRequestSelection() {
            this._sSelectedRequestId = null;
            this._sSelectedTaskId = null;
            this._sTaskDetailLoadToken = null;
            this._sSelectedPartyId = null;
            this._setRequestsLayout(fLibrary.LayoutType.OneColumn);
            this.getView().getModel("requestEdit").setProperty("/editable", false);
            this.getView().getModel("processFlow").setData({
                visible: false,
                loading: false,
                steps: []
            });
        },

        async _showRequestTaskDetail(sTaskId) {
            this._sSelectedTaskId = sTaskId;
            const sLoadToken = `${sTaskId}-${Date.now()}`;
            const oTaskPage = this.byId("requestTaskObjectPage");
            const sTaskPath = `/RequestDetailTasks(guid'${sTaskId}')`;

            this._sTaskDetailLoadToken = sLoadToken;
            this.byId("requestsFlexibleColumnLayout").toEndColumnPage(oTaskPage.getId());
            oTaskPage.unbindElement();
            oTaskPage.setBindingContext(null);
            this.getView().getModel("statusEdit").setProperty("/taskStatus", "");
            this.getView().getModel("processorEdit").setProperty("/taskProcessorUser_ID", "");
            this.getView().getModel("processorEdit").setProperty("/taskProcessorName", "");
            this.getView().getModel("processorEdit").setProperty("/taskTeam_ID", "");
            this.getView().getModel("processorEdit").setProperty("/taskTeamName", "");
            this._setRequestsLayout(fLibrary.LayoutType.ThreeColumnsEndExpanded);

            this.showBusy();
            try {
                const oTask = await this._readEntry(sTaskPath, {
                    urlParameters: {
                        "$expand": "request"
                    }
                });

                if (this._sTaskDetailLoadToken !== sLoadToken) {
                    return;
                }

                oTaskPage.bindElement({
                    path: sTaskPath,
                    parameters: {
                        expand: "request"
                    }
                });
                this.getView().getModel("statusEdit").setProperty("/taskStatus", oTask.status_code || "");
                this.getView().getModel("processorEdit").setProperty("/taskProcessorUser_ID", oTask.processorUser_ID || "");
                this.getView().getModel("processorEdit").setProperty("/taskProcessorName", oTask.processor || "");
                this.getView().getModel("processorEdit").setProperty("/taskTeam_ID", oTask.processorTeam_ID || "");
                this.getView().getModel("processorEdit").setProperty("/taskTeamName", oTask.processorTeamName || "");
                this._loadTaskStepOptions("requestTaskObjectPage");
            } catch (oError) {
                if (this._sTaskDetailLoadToken === sLoadToken) {
                    MessageBox.error(this.getErrorMessage(oError, this.getText("actionFailedMessage")));
                }
            } finally {
                this.hideBusy();
            }
        },

        _showInvolvedPartyDetail(sPartyId) {
            this._sSelectedPartyId = sPartyId;
            this.byId("requestsFlexibleColumnLayout").toEndColumnPage(this.byId("requestPartyObjectPage").getId());
            this.byId("requestPartyObjectPage").bindElement({
                path: `/ProcessInvolvedParties(guid'${sPartyId}')`,
                parameters: {
                    // expand: "request,user"
                    expand: "request"
                },
                events: {
                    dataRequested: this.onDataRequested.bind(this),
                    dataReceived: this.onDataReceived.bind(this)
                }
            });
            this._setRequestsLayout(fLibrary.LayoutType.ThreeColumnsEndExpanded);
        },

        async _completeRequestTask(sAction, sSuccessTextKey) {
            if (!this._sSelectedTaskId) {
                MessageToast.show(this.getText("selectTaskMessage"));
                return;
            }

            const sRemarks = this.byId("requestTaskRemarksTextArea").getValue();
            let iSendBackStepNo;

            if (sAction === "sendBack") {
                iSendBackStepNo = await this._chooseSendBackStep();

                if (!iSendBackStepNo) {
                    return;
                }
            }

            this.showBusy();

            try {
                let bCompleted = true;

                if (sAction === "approveTask") {
                    bCompleted = await this._approveTaskWithGuidedDecision(this._sSelectedTaskId, sRemarks);
                } else {
                    const oPayload = {
                        taskId: this._sSelectedTaskId,
                        remarks: sRemarks
                    };

                    if (sAction === "sendBack") {
                        oPayload.targetStepNo = iSendBackStepNo;
                    }

                    await this.callAction(sAction, oPayload);
                }

                if (!bCompleted) {
                    return;
                }

                MessageToast.show(this.getText(sSuccessTextKey));
                // this.byId("requestTaskRemarksTextArea").setValue("");
                this._refreshAfterTaskChange();
                this.byId("requestTaskObjectPage").getElementBinding().refresh();
            } catch (oError) {
                MessageBox.error(this.getErrorMessage(oError, this.getText("actionFailedMessage")));
            } finally {
                this.hideBusy();
            }
        },

        async _approveTaskWithGuidedDecision(sTaskId, sRemarks) {
            await this.callAction("approveTask", {
                taskId: sTaskId,
                remarks: sRemarks
            });

            return true;
        },

        async _completeGuidedStepWithDecision(iStepNo, sRemarks) {
            let sProgressionMode = "continue";
            const oAnalysisResponse = await this.callAction("analyzeGuidedStepCompletion", {
                requestId: this._sSelectedRequestId,
                stepNo: iStepNo
            });
            const oAnalysis = oAnalysisResponse.value || oAnalysisResponse;

            this.hideBusy();

            if (oAnalysis.requiresDecision) {
                sProgressionMode = await this._chooseGuidedProgression(oAnalysis);

                if (!sProgressionMode) {
                    return false;
                }
            }

            this.showBusy();
            await this.callAction("completeGuidedStep", {
                requestId: this._sSelectedRequestId,
                stepNo: iStepNo,
                remarks: sRemarks,
                progressionMode: sProgressionMode
            });

            return true;
        },

        async onCompleteGuidedStep(oEvent) {
            const oStep = oEvent.getSource().getBindingContext("processFlow")?.getObject()
                || this.getView().getModel("processFlow").getProperty("/selectedStep");
            const iStepNo = Number(oStep?.stepNo || 0);

            if (!this._sSelectedRequestId || !iStepNo) {
                MessageToast.show(this.getText("selectRequestMessage"));
                return;
            }

            this.showBusy();

            try {
                const bCompleted = await this._completeGuidedStepWithDecision(
                    iStepNo,
                    this.getText("completeStepButton")
                );

                if (!bCompleted) {
                    return;
                }

                MessageToast.show(this.getText("guidedStepCompletedMessage"));
                this._refreshAfterTaskChange();
            } catch (oError) {
                MessageBox.error(this.getErrorMessage(oError, this.getText("guidedStepCompleteErrorMessage")));
            } finally {
                this.hideBusy();
            }
        },

        _chooseGuidedProgression(oAnalysis) {
            return new Promise((resolve) => {
                const sRetrigger = this.getText("retriggerNextStepButton");
                const sJump = this.getText("jumpToIncompleteStepButton");
                const sCancel = MessageBox.Action.CANCEL;

                MessageBox.warning(this.getText("guidedStepAlreadyCompletedMessage", [
                    oAnalysis.nextStepName || oAnalysis.nextStepNo,
                    oAnalysis.incompleteStepName || oAnalysis.incompleteStepNo
                ]), {
                    actions: [sJump, sRetrigger, sCancel],
                    emphasizedAction: sJump,
                    onClose: (sAction) => {
                        if (sAction === sJump) {
                            resolve("jumpIncomplete");
                            return;
                        }

                        if (sAction === sRetrigger) {
                            resolve("retriggerNext");
                            return;
                        }

                        resolve(null);
                    }
                });
            });
        },

        _createEmptyTask() {
            return {
                taskName: "",
                stepNo: "",
                steps: [],
                processorUser_ID: "",
                processorName: "",
                processor: "",
                processorEmail: "",
                processorTeam_ID: "",
                processorTeamName: "",
                role: "",
                isMandatory: false
            };
        },

        _createEmptyParty() {
            return {
                user_ID: "",
                displayName: "",
                email: "",
                department: "",
                purpose: ""
            };
        },

        _createEmptyEmailDraft() {
            return {
                requestId: "",
                toRecipients: "",
                toTokens: [],
                ccRecipients: "",
                subject: "",
                body: "",
                attachments: []
            };
        },

        _applyProcessorSelection(oContext, sTarget) {
            if (!oContext) {
                return;
            }

            const sId = oContext.getProperty("ID");
            const sName = oContext.getProperty("displayName");
            const sEmail = oContext.getProperty("email") || oContext.getProperty("userPrincipalName");

            const sDemandModel = DEMAND_TASK_MODELS[sTarget];
            if (sDemandModel) {
            const oDemandModel = this.getView().getModel(sDemandModel);
            oDemandModel.setProperty("/processorUser_ID", sId);
            oDemandModel.setProperty("/processorName", sName);
            oDemandModel.setProperty("/processor", sName);
            oDemandModel.setProperty("/processorEmail", sEmail);
            oDemandModel.setProperty("/processorTeam_ID", "");
            oDemandModel.setProperty("/processorTeamName", "");
            return;
        }
            if (sTarget === "newTask") {
                const oTaskModel = this.getView().getModel("newTask");
                oTaskModel.setProperty("/processorUser_ID", sId);
                oTaskModel.setProperty("/processorName", sName);
                oTaskModel.setProperty("/processor", sName);
                oTaskModel.setProperty("/processorEmail", sEmail);
                oTaskModel.setProperty("/processorTeam_ID", "");
                oTaskModel.setProperty("/processorTeamName", "");
                return;
            }

            const oProcessorModel = this.getView().getModel("processorEdit");
            const sPrefix = sTarget === "request" ? "request" : "task";

            oProcessorModel.setProperty(`/${sPrefix}ProcessorUser_ID`, sId);
            oProcessorModel.setProperty(`/${sPrefix}ProcessorName`, sName);

            if (sPrefix === "task") {
                oProcessorModel.setProperty("/taskTeam_ID", "");
                oProcessorModel.setProperty("/taskTeamName", "");
            }
        },

        _applyTeamSelection(oContext, sTarget) {
            if (!oContext) {
                return;
            }

            const sTeamId = oContext.getProperty("ID");
            const sTeamName = oContext.getProperty("name");

            const sDemandModel = DEMAND_TASK_MODELS[sTarget];

            if (sDemandModel) {
                const oDemandModel = this.getView().getModel(sDemandModel);
                oDemandModel.setProperty("/processorTeam_ID", sTeamId);
                oDemandModel.setProperty("/processorTeamName", sTeamName);
                oDemandModel.setProperty("/processorUser_ID", "");
                oDemandModel.setProperty("/processorName", "");
                oDemandModel.setProperty("/processor", "");
                oDemandModel.setProperty("/processorEmail", "");
                return;
            }

            if (sTarget === "newTask") {
                const oTaskModel = this.getView().getModel("newTask");
                oTaskModel.setProperty("/processorTeam_ID", sTeamId);
                oTaskModel.setProperty("/processorTeamName", sTeamName);
                oTaskModel.setProperty("/processorUser_ID", "");
                oTaskModel.setProperty("/processorName", "");
                oTaskModel.setProperty("/processor", "");
                oTaskModel.setProperty("/processorEmail", "");
                return;
            }

            const oProcessorModel = this.getView().getModel("processorEdit");
            const sPrefix = sTarget === "request" ? "request" : "task";

            oProcessorModel.setProperty(`/${sPrefix}Team_ID`, sTeamId);
            oProcessorModel.setProperty(`/${sPrefix}TeamName`, sTeamName);

            if (sPrefix === "task") {
                oProcessorModel.setProperty("/taskProcessorUser_ID", "");
                oProcessorModel.setProperty("/taskProcessorName", "");
            }
        },

        _applyPartySelection(oContext) {
            if (!oContext) {
                return;
            }

            const oModel = this.getView().getModel("newParty");
            oModel.setProperty("/user_ID", oContext.getProperty("ID"));
            oModel.setProperty("/displayName", oContext.getProperty("displayName"));
            oModel.setProperty("/email", oContext.getProperty("email"));
            oModel.setProperty("/department", oContext.getProperty("department"));
        },

        _addEmailToRecipients(aUsers) {
            const oModel = this.getView().getModel("emailDraft");
            const aTokens = [...(oModel.getProperty("/toTokens") || [])];
            const mExisting = new Map(aTokens.map((oToken) => [String(oToken.email || "").toLowerCase(), oToken]));

            aUsers
                .filter((oUser) => oUser.email)
                .forEach((oUser) => {
                    const sEmail = String(oUser.email).trim();
                    const sKey = sEmail.toLowerCase();

                    if (!mExisting.has(sKey)) {
                        mExisting.set(sKey, {
                            email: sEmail,
                            text: oUser.displayName
                                ? `${oUser.displayName} <${sEmail}>`
                                : sEmail
                        });
                    }
                });

            this._setEmailToTokens([...mExisting.values()]);
        },

        _setEmailToTokens(aTokens) {
            const oModel = this.getView().getModel("emailDraft");

            oModel.setProperty("/toTokens", aTokens);
            oModel.setProperty("/toRecipients", aTokens.map((oToken) => oToken.email).join(", "));
        },

        _filterUsers(oDialog, sQuery) {
            const oBinding = oDialog.getBinding("items");

            if (!sQuery) {
                oBinding.filter([]);
                return;
            }

            oBinding.filter([
                new Filter({
                    filters: [
                        new Filter("displayName", FilterOperator.Contains, sQuery),
                        new Filter("email", FilterOperator.Contains, sQuery),
                        new Filter("userPrincipalName", FilterOperator.Contains, sQuery)
                    ],
                    and: false
                })
            ]);
        },

        _refreshRequestDetailBinding() {
            const oBinding = this.byId("requestObjectPage").getElementBinding();

            if (oBinding) {
                oBinding.refresh(true);
            }
        },

        _refreshRequestHeader() {
            this._refreshRequestDetailBinding();
        },

        _refreshProcessFlow(iPreferredStepNo) {
            if (this._sSelectedRequestId) {
                this._loadProcessFlow(this._sSelectedRequestId, null, iPreferredStepNo);
            }
        },

        _refreshSectionTable(sTableId) {
            this.byId(sTableId)?.getBinding("items")?.refresh(true);
        },

        _refreshTaskSection() {
            this._refreshSectionTable("requestTasksTable");
        },

        _refreshPartySection() {
            this._refreshSectionTable("requestPartiesTable");
        },

        _refreshAttachmentSection() {
            this._refreshSectionTable("requestAttachmentsTable");
        },

        _refreshHistorySection() {
            this._refreshSectionTable("requestHistoryTable");
        },

        _refreshEmailSection() {
            this._refreshSectionTable("requestEmailsTable");
        },

        _refreshAllRequestSections() {
            this._refreshRequestHeader();
            this._refreshTaskSection();
            this._refreshPartySection();
            this._refreshAttachmentSection();
            this._refreshHistorySection();
        },

        _refreshAfterTaskChange(iPreferredStepNo) {
            this._refreshRequestHeader();
            this._refreshTaskSection();
            this._refreshHistorySection();
            this._refreshProcessFlow(iPreferredStepNo);
        },

        async _loadProcessFlow(sRequestId, oBoundRequest, iPreferredStepNo) {
            const oProcessFlowModel = this.getView().getModel("processFlow");

            if (!sRequestId) {
                oProcessFlowModel.setData({ visible: false, loading: false, steps: [] });
                return;
            }

            oProcessFlowModel.setProperty("/loading", true);

            try {
                const oRequest = oBoundRequest?.subProcessType_code
                    ? { ...oBoundRequest }
                    : await this._readEntry(`/ProcessRequests(guid'${sRequestId}')`);
                const oTaskResponse = await this.callAction("getGuidedProcessTasks", {
                    requestId: sRequestId
                });

                oRequest.tasks = oTaskResponse.value || oTaskResponse || [];
                const aSteps = await this._readList("/ProcessStepConfig", {
                    filters: [new Filter("subProcessType_code", FilterOperator.EQ, oRequest.subProcessType_code)]
                });

                aSteps.sort((oLeft, oRight) => Number(oLeft.stepNo || 0) - Number(oRight.stepNo || 0));
                const aProcessSteps = this._buildProcessFlowSteps(aSteps, oRequest, iPreferredStepNo);
                const oPreferredStep = iPreferredStepNo == null
                    ? null
                    : aProcessSteps.find((oStep) => Number(oStep.stepNo || 0) === Number(iPreferredStepNo || 0));
                const oSelectedStep = oPreferredStep
                    || aProcessSteps.find((oStep) => oStep.isCurrent)
                    || aProcessSteps.find((oStep) => oStep.completeEnabled)
                    || aProcessSteps.find((oStep) => oStep.state !== "Success")
                    || aProcessSteps[0]
                    || {};

                this._markSelectedProcessStep(aProcessSteps, oSelectedStep.stepNo);

                oProcessFlowModel.setData({
                    visible: Boolean(aSteps.length),
                    loading: false,
                    steps: aProcessSteps,
                    selectedStep: oSelectedStep
                });
            } catch (oError) {
                oProcessFlowModel.setData({ visible: false, loading: false, steps: [] });
            }
        },

        onGuideMilestonePress(oEvent) {
            const oStep = oEvent.getSource().getBindingContext("processFlow")?.getObject();

            if (!oStep) {
                return;
            }

            this._selectGuidedProcessStep(oStep);
        },

        onShowPreviousGuidedStep() {
            this._selectAdjacentGuidedProcessStep(-1);
        },

        onShowNextGuidedStep() {
            this._selectAdjacentGuidedProcessStep(1);
        },

        _selectAdjacentGuidedProcessStep(iDirection) {
            const oProcessFlowModel = this.getView().getModel("processFlow");
            const aSteps = oProcessFlowModel.getProperty("/steps") || [];
            const oSelectedStep = oProcessFlowModel.getProperty("/selectedStep") || {};

            if (!aSteps.length) {
                return;
            }

            const iCurrentIndex = Math.max(0, aSteps.findIndex((oStep) =>
                Number(oStep.stepNo || 0) === Number(oSelectedStep.stepNo || 0)
            ));
            const iNextIndex = (iCurrentIndex + iDirection + aSteps.length) % aSteps.length;

            this._selectGuidedProcessStep(aSteps[iNextIndex]);
        },

        _selectGuidedProcessStep(oStep) {
            if (!oStep) {
                return;
            }

            const oProcessFlowModel = this.getView().getModel("processFlow");
            const aSteps = oProcessFlowModel.getProperty("/steps") || [];

            this._markSelectedProcessStep(aSteps, oStep.stepNo);
            oProcessFlowModel.setProperty("/steps", aSteps);
            oProcessFlowModel.setProperty("/selectedStep", {
                ...oStep,
                selected: true
            });
        },

        _buildProcessFlowSteps(aSteps, oRequest, iPreferredStepNo) {
            const aTasks = this._normalizeCollection(oRequest.tasks);
            const iCurrentStep = Number(iPreferredStepNo || oRequest.currentStep || 0);
            const bRequestEditable = this._isRequestEditable(oRequest);
            const bRequestCompleted = oRequest.status_code === "COMPLETED";
            const mTasksByStep = aTasks.reduce((mResult, oTask) => {
                const sStepNo = String(Number(oTask.stepNo || 0));
                const aStepTasks = mResult.get(sStepNo) || [];

                aStepTasks.push(oTask);
                mResult.set(sStepNo, aStepTasks);
                return mResult;
            }, new Map());

            const bAllProcessTasksApproved = Boolean(aTasks.length)
                && aTasks.every((oTask) => this._isGuidedTaskApproved(oTask));

            return aSteps.map((oStep, iIndex) => {
                const aStepTasks = mTasksByStep.get(String(Number(oStep.stepNo || 0))) || [];
                const aMandatoryTasks = aStepTasks.filter((oTask) => this._isTruthy(oTask.isMandatory));
                const bMandatory = aMandatoryTasks.some((oTask) => !this._isGuidedTaskApproved(oTask));
                const bMandatoryTasksApproved = Boolean(aMandatoryTasks.length)
                    && aMandatoryTasks.every((oTask) => this._isGuidedTaskApproved(oTask));
                const oOpenTask = aStepTasks.find((oTask) => this._isOpenLikeTask(oTask));
                const bAllTasksApproved = Boolean(aStepTasks.length)
                    && aStepTasks.some((oTask) => this._taskStatusCode(oTask) === "APPROVED")
                    && aStepTasks.every((oTask) => this._isGuidedTaskApproved(oTask));
                const bRejected = aStepTasks.some((oTask) => this._taskStatusCode(oTask) === "REJECTED");
                const bSentBack = aStepTasks.some((oTask) => this._taskStatusCode(oTask) === "SENT_BACK");
                const bCurrent = Number(oStep.stepNo || 0) === iCurrentStep;
                const oNextStep = aSteps[iIndex + 1];
                const bFinalStep = !oNextStep;
                const bCanCompleteStep = bFinalStep
                    ? bAllProcessTasksApproved
                    : (!bMandatory || bMandatoryTasksApproved);
                let sState = "None";
                let sStatusText = this.getText("processStepPendingLabel");
                let sIcon = "sap-icon://circle-task";
                let sButtonType = "Transparent";

                if (bRequestCompleted) {
                    sState = "Success";
                    sStatusText = this.getText("processStepCompletedLabel");
                    sIcon = "sap-icon://accept";
                    sButtonType = "Accept";
                } else if (bRejected) {
                    sState = "Error";
                    sStatusText = this.getText("processStepRejectedLabel");
                    sIcon = "sap-icon://decline";
                    sButtonType = "Reject";
                } else if (bSentBack) {
                    sState = "Warning";
                    sStatusText = this.getText("processStepSentBackLabel");
                    sIcon = "sap-icon://undo";
                    sButtonType = "Default";
                } else if (bCurrent) {
                    sState = "Information";
                    sStatusText = bAllTasksApproved
                        ? this.getText("processStepReadyLabel")
                        : this.getText("processStepPendingLabel");
                    sIcon = "sap-icon://process";
                    sButtonType = "Emphasized";
                } else if (bAllTasksApproved) {
                    sState = "Success";
                    sStatusText = this.getText("processStepCompletedLabel");
                    sIcon = "sap-icon://accept";
                    sButtonType = "Accept";
                }

                return {
                    stepNo: oStep.stepNo,
                    stepName: oStep.stepName,
                    activityDescription: oStep.activityDescription,
                    role: oStep.role,
                    isMandatory: bMandatory,
                    mandatoryText: bMandatory ? this.getText("mandatoryLabel") : this.getText("optionalLabel"),
                    sequenceText: this.getText("processStepNumberLabel", [oStep.stepNo]),
                    statusText: sStatusText,
                    state: sState,
                    icon: sIcon,
                    buttonType: sButtonType,
                    isCurrent: bCurrent && !bRequestCompleted,
                    selected: false,
                    taskId: oOpenTask?.ID || "",
                    completeEnabled: oStep.stepType !== "LOA" && bRequestEditable && bCurrent && bCanCompleteStep
                };
            });
        },

        _isClosingProcessStep(oStep) {
            return /closed|complete|completed/i.test(oStep?.stepName || "");
        },

        _isGuidedTaskApproved(oTask) {
            return this._taskStatusCode(oTask) === "APPROVED"
                || (this._isTruthy(oTask.isLoaApproval) && oTask.decision === "SUPERSEDED");
        },

        _taskStatusCode(oTask) {
            const vStatus = oTask?.status_code;

            return String(vStatus?.code || vStatus || "").toUpperCase();
        },

        _isOpenLikeTask(oTask) {
            return ["OPEN", "SENT_BACK"].includes(this._taskStatusCode(oTask));
        },

        async _loadTaskStepOptions(sObjectPageId) {
            const oTaskActionModel = this.getView().getModel("taskAction");
            const oContext = this.byId(sObjectPageId)?.getBindingContext();
            const sSubProcessTypeCode = oContext?.getProperty("request/subProcessType_code");
            const iCurrentStepNo = Number(oContext?.getProperty("stepNo") || 0);

            oTaskActionModel.setData({
                sendBackStepNo: "",
                steps: []
            });

            if (!sSubProcessTypeCode) {
                return;
            }

            try {
                const aSteps = await this._readList("/ProcessStepConfig", {
                    filters: [new Filter("subProcessType_code", FilterOperator.EQ, sSubProcessTypeCode)]
                });
                const aStepItems = aSteps
                    .sort((oLeft, oRight) => Number(oLeft.stepNo || 0) - Number(oRight.stepNo || 0))
                    .filter((oStep) => Number(oStep.stepNo || 0) < iCurrentStepNo)
                    .map((oStep) => ({
                        stepNo: String(oStep.stepNo),
                        text: this.getText("sendBackStepOptionText", [oStep.stepNo, oStep.stepName || ""])
                    }));

                oTaskActionModel.setData({
                    sendBackStepNo: aStepItems[0]?.stepNo || "",
                    steps: aStepItems
                });
            } catch (oError) {
                MessageToast.show(this.getText("sendBackStepsLoadErrorMessage"));
            }
        },

        _chooseSendBackStep() {
            const aSteps = this.getView().getModel("taskAction").getProperty("/steps") || [];

            if (!aSteps.length) {
                MessageBox.warning(this.getText("noPreviousSendBackStepsMessage"));
                return Promise.resolve(null);
            }

            return new Promise((resolve) => {
                const oSelect = new Select({
                    width: "100%",
                    selectedKey: aSteps[0].stepNo,
                    items: aSteps.map((oStep) => new Item({
                        key: oStep.stepNo,
                        text: oStep.text
                    }))
                });
                const oDialog = new Dialog({
                    title: this.getText("sendBackTargetStepDialogTitle"),
                    contentWidth: "24rem",
                    content: [
                        new Text({
                            text: this.getText("sendBackTargetStepDialogText"),
                            wrapping: true
                        }),
                        oSelect
                    ],
                    beginButton: new Button({
                        text: this.getText("sendBackButton"),
                        type: "Emphasized",
                        press: () => {
                            resolve(Number(oSelect.getSelectedKey()));
                            oDialog.close();
                        }
                    }),
                    endButton: new Button({
                        text: this.getText("cancelButton"),
                        press: () => {
                            resolve(null);
                            oDialog.close();
                        }
                    })
                });

                oDialog.attachAfterClose(() => oDialog.destroy());
                this.getView().addDependent(oDialog);
                oDialog.open();
            });
        },

        _isRequestEditable(oRequest) {
            return this._canCurrentUserModifyRequest(oRequest);
        },

        _canCurrentUserModifyRequest(oRequest) {
            return Boolean(
                oRequest?.reservedBy
                && oRequest?.processorUser_ID
                && oRequest.processorUser_ID === this._sCurrentReservationUserId
                && !["COMPLETED", "REJECTED", "PENDING_APPROVAL"].includes(oRequest?.status_code)
            );
        },

        _normalizeCollection(vCollection) {
            if (Array.isArray(vCollection)) {
                return vCollection;
            }

            return vCollection?.results || [];
        },

        formatCollectionCount(vCollection) {
            return this._normalizeCollection(vCollection).length;
        },

        _isTruthy(vValue) {
            if (typeof vValue === "string") {
                return vValue.toLowerCase() === "true" || vValue === "1";
            }

            return Boolean(vValue);
        },

        _markSelectedProcessStep(aSteps, iSelectedStepNo) {
            aSteps.forEach((oStep) => {
                oStep.selected = Number(oStep.stepNo || 0) === Number(iSelectedStepNo || 0);
            });
        },

        _readEntry(sPath, oParameters) {
            return new Promise((resolve, reject) => {
                this.getModel().read(sPath, {
                    ...(oParameters || {}),
                    success: resolve,
                    error: reject
                });
            });
        },

        _readList(sPath, oParameters) {
            return new Promise((resolve, reject) => {
                this.getModel().read(sPath, {
                    ...(oParameters || {}),
                    success: (oData) => resolve(oData.results || []),
                    error: reject
                });
            });
        },

        _confirmDelete(sMessageKey, aArguments) {
            return new Promise((resolve) => {
                MessageBox.confirm(this.getText(sMessageKey, aArguments), {
                    actions: [MessageBox.Action.DELETE, MessageBox.Action.CANCEL],
                    emphasizedAction: MessageBox.Action.DELETE,
                    onClose: (sAction) => resolve(sAction === MessageBox.Action.DELETE)
                });
            });
        },

        async _uploadAttachments(sRequestId, aFiles) {
            const sToken = await this._fetchCsrfToken();

            for (let iIndex = 0; iIndex < aFiles.length; iIndex += 1) {
                const oFile = aFiles[iIndex];

                this._setAttachmentUploadStatus(iIndex, {
                    statusText: this.getText("attachmentUploadingStatus"),
                    statusState: "Information"
                });

                try {
                    const oAttachment = await this._createAttachmentMetadata(sRequestId, oFile, sToken);
                    await this._uploadAttachmentContent(oAttachment.ID, oFile, sToken, (iPercent) => {
                        this._setAttachmentUploadStatus(iIndex, {
                            progress: iPercent,
                            progressText: `${iPercent}%`,
                            statusText: iPercent === 100
                                ? this.getText("attachmentProcessingStatus")
                                : this.getText("attachmentUploadingStatus")
                        });
                    });
                    this._setAttachmentUploadStatus(iIndex, {
                        progress: 100,
                        progressText: "100%",
                        statusText: this.getText("attachmentUploadedStatus"),
                        statusState: "Success"
                    });
                } catch (oError) {
                    this._setAttachmentUploadStatus(iIndex, {
                        statusText: this.getText("attachmentUploadFailedStatus"),
                        statusState: "Error"
                    });
                    throw oError;
                }
            }
        },

        _startAttachmentUploads(aFiles) {
            this.getView().getModel("uploads").setData({
                active: true,
                items: aFiles.map((oFile) => ({
                    name: oFile.name,
                    progress: 0,
                    progressText: "0%",
                    statusText: this.getText("attachmentQueuedStatus"),
                    statusState: "None"
                }))
            });
        },

        _setAttachmentUploadStatus(iIndex, oValues) {
            const oModel = this.getView().getModel("uploads");

            Object.entries(oValues).forEach(([sProperty, vValue]) => {
                oModel.setProperty(`/items/${iIndex}/${sProperty}`, vValue);
            });
        },

        _validateAttachmentFiles(aFiles) {
            const oOversizedFile = aFiles.find((oFile) => oFile.size > MAX_ATTACHMENT_SIZE_BYTES);

            if (!oOversizedFile) {
                return true;
            }

            MessageBox.warning(this.getText("attachmentSizeExceededMessage", [
                oOversizedFile.name,
                MAX_ATTACHMENT_SIZE_MB
            ]));
            return false;
        },

        async _createAttachmentMetadata(sRequestId, oFile, sToken) {
            const oResponse = await fetch(this.getServiceV4Url("ProcessAttachments"), {
                method: "POST",
                credentials: "same-origin",
                headers: {
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "X-CSRF-Token": sToken
                },
                body: JSON.stringify({
                    request_ID: sRequestId,
                    filename: oFile.name,
                    mimeType: oFile.type || "application/octet-stream"
                })
            });

            if (!oResponse.ok) {
                throw new Error(this.getText("attachmentMetadataErrorMessage", [oFile.name]));
            }

            return oResponse.json();
        },

        _uploadAttachmentContent(sAttachmentId, oFile, sToken, fnProgress) {
            return new Promise((resolve, reject) => {
                const oRequest = new XMLHttpRequest();

                oRequest.open("PUT", this.getServiceV4Url(`ProcessAttachments(ID=${sAttachmentId})/content`));
                oRequest.withCredentials = true;
                oRequest.setRequestHeader("Content-Type", oFile.type || "application/octet-stream");
                oRequest.setRequestHeader("X-CSRF-Token", sToken);
                oRequest.upload.onprogress = (oEvent) => {
                    if (oEvent.lengthComputable) {
                        fnProgress(Math.round((oEvent.loaded / oEvent.total) * 100));
                    }
                };
                oRequest.onload = () => {
                    if (oRequest.status >= 200 && oRequest.status < 300) {
                        resolve();
                        return;
                    }

                    reject(new Error(this.getText("attachmentContentErrorMessage", [oFile.name])));
                };
                oRequest.onerror = () => {
                    reject(new Error(this.getText("attachmentContentErrorMessage", [oFile.name])));
                };
                oRequest.send(oFile);
            });
        },

        async _fetchAttachmentContent(oContext) {
            const sAttachmentId = oContext.getProperty("ID");
            const sFilename = oContext.getProperty("filename") || this.getText("attachmentFallbackFileName");
            const sMimeType = oContext.getProperty("mimeType") || "application/octet-stream";
            const oResponse = await fetch(this.getServiceV4Url(`ProcessAttachments(ID=${sAttachmentId})/content`), {
                method: "GET",
                credentials: "same-origin"
            });

            if (!oResponse.ok) {
                throw new Error(this.getText("attachmentReadErrorMessage", [sFilename]));
            }

            return {
                filename: sFilename,
                blob: await oResponse.blob(),
                mimeType: sMimeType
            };
        }
    });
});

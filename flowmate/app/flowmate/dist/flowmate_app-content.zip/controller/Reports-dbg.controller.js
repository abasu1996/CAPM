sap.ui.define([
    "flowmate/controller/BaseController",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageBox"
], (BaseController, JSONModel, MessageBox) => {
    "use strict";

    return BaseController.extend("flowmate.controller.Reports", {
        onInit() {
            const oTo = new Date();
            const oFrom = new Date(oTo);
            oFrom.setDate(oFrom.getDate() - 89);
            this.getView().setModel(new JSONModel({
                filters: {
                    fromDate: oFrom,
                    toDate: oTo,
                    processTypeCode: "",
                    statusCode: ""
                },
                totalRequests: 0,
                openRequests: 0,
                completedRequests: 0,
                overdueRequests: 0,
                slaCompliancePercent: 100,
                statusBreakdown: [],
                processBreakdown: [],
                monthlyTrend: [],
                teamWorkload: [],
                overdueTasks: [],
                loaded: false
            }), "reports");
            this.getRouter().getRoute("RouteReports").attachPatternMatched(this.onRouteMatched, this);
        },

        onRouteMatched() {
            this.setOneColumnLayout();
            this._loadDashboard();
        },

        onApplyFilters() {
            this._loadDashboard();
        },

        onResetFilters() {
            const oTo = new Date();
            const oFrom = new Date(oTo);
            oFrom.setDate(oFrom.getDate() - 89);
            this.getView().getModel("reports").setProperty("/filters", {
                fromDate: oFrom,
                toDate: oTo,
                processTypeCode: "",
                statusCode: ""
            });
            this._loadDashboard();
        },

        onOverdueTaskPress(oEvent) {
            const sTaskId = oEvent.getSource().getBindingContext("reports")?.getProperty("ID");
            if (sTaskId) {
                this.navTo("RouteApprovalDetail", { taskId: sTaskId });
            }
        },

        async _loadDashboard() {
            const oModel = this.getView().getModel("reports");
            const oFilters = oModel.getProperty("/filters");
            if (!oFilters.fromDate || !oFilters.toDate || oFilters.fromDate > oFilters.toDate) {
                MessageBox.warning(this.getText("reportsInvalidDateRange"));
                return;
            }

            this.showBusy();
            try {
                const oResult = await this.callAction("getReportDashboard", {
                    filter: {
                        fromDate: this._formatDate(oFilters.fromDate),
                        toDate: this._formatDate(oFilters.toDate),
                        processTypeCode: oFilters.processTypeCode || null,
                        statusCode: oFilters.statusCode || null
                    }
                });
                oModel.setData({
                    filters: oFilters,
                    ...(oResult.value || oResult),
                    loaded: true
                });
            } catch (oError) {
                MessageBox.error(oError.message || this.getText("reportsLoadFailed"));
            } finally {
                this.hideBusy();
            }
        },

        _formatDate(oDate) {
            const iOffset = oDate.getTimezoneOffset();
            return new Date(oDate.getTime() - iOffset * 60000).toISOString().slice(0, 10);
        }
    });
});
